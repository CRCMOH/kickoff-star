// P80 — real, confirmed, SHIPPING bug found during an attribute-reduction
// scoping pass: several equipment items' boosts targeted attribute keys
// ('firstTouch', 'finishing') that don't exist in the current 12-attribute
// schema (renamed to 'dribbling'/'shooting' at some point, economy.ts never
// updated). effectiveValues()'s `if (out[attr] === undefined) continue`
// silently no-ops any boost to a key that isn't real — so those items
// delivered LESS than half their advertised value with zero indication
// anywhere. The most expensive item in the shop (£340 Custom-Fit Boots)
// had HALF its boosts dead. This audit makes sure every boost key in the
// shop always resolves to a real, current attribute — for any position,
// not just outfield — so a future rename/reduction can't reintroduce this
// silently again.
import { SHOP_ITEMS } from '../src/engine/economy'
import { ARCHETYPES } from '../src/engine/archetypes'
import { OUTFIELD_ATTRIBUTES, GOALKEEPER_ATTRIBUTES } from '../src/types/attributes'

let fails = 0
function check(cond: boolean, msg: string) {
  if (cond) console.log(`  ✓ ${msg}`)
  else { console.log(`  ✗ ${msg}`); fails++ }
}

const validKeys = new Set<string>([...OUTFIELD_ATTRIBUTES, ...GOALKEEPER_ATTRIBUTES])

console.log('[A] every equipment boost key resolves to a real, current attribute')
for (const item of SHOP_ITEMS) {
  if (!item.boosts) continue
  for (const key of Object.keys(item.boosts)) {
    check(validKeys.has(key), `"${item.name}" boosts a real attribute: ${key}`)
  }
}

console.log('\n[B] every archetype boost/tradeoff resolves to a real, current attribute (found this same bug class living here too during the P81 attribute-reduction pass)')
for (const arch of ARCHETYPES) {
  for (const key of arch.boosts) check(validKeys.has(key), `"${arch.label}" boosts a real attribute: ${key}`)
  for (const key of arch.tradeoffs) check(validKeys.has(key), `"${arch.label}" trades off a real attribute: ${key}`)
  if (arch.gkAlternative) {
    for (const key of arch.gkAlternative.boosts) check(validKeys.has(key), `"${arch.label}" (GK) boosts a real attribute: ${key}`)
    for (const key of arch.gkAlternative.tradeoffs) check(validKeys.has(key), `"${arch.label}" (GK) trades off a real attribute: ${key}`)
  }
}

console.log('\n[C] P84 — a team\'s notable players\' season goals reset at season rollover, in both grassroots and academy (real bug: previously accumulated forever across every season of the whole career)')
{
  const { initLeagueWorld, applyPromotionRelegation } = await import('../src/engine/league')
  const { initAcademyWorld, applyAcademyPromotion } = await import('../src/engine/academy')

  const league = initLeagueWorld('Test United')
  // simulate a scorer having racked up goals across a season
  const div = league.divisions[league.playerDivision]
  const teamWithScorer = div.teams.find((t) => t.notablePlayers.length > 0)!
  teamWithScorer.notablePlayers[0].seasonGoals = 27
  // standings need real point totals so the promotion/relegation slice logic has something to sort
  for (const s of div.standings) s.points = Math.floor(Math.random() * 40)

  const after = applyPromotionRelegation(league)
  const survivedTeam = Object.values(after.divisions).flatMap((d) => d.teams).find((t) => t.id === teamWithScorer.id)
  check(!!survivedTeam, 'the team with the scorer is still findable after the season rolls over (real identity preserved)')
  check(survivedTeam!.notablePlayers[0].seasonGoals === 0, `grassroots: a notable player's goals reset to 0 at season rollover (was 27, is now ${survivedTeam!.notablePlayers[0].seasonGoals})`)

  const academy = initAcademyWorld('Test Academy', 50)
  const adiv = academy.divisions[academy.playerDivision]
  const aTeamWithScorer = adiv.teams.find((t) => t.notablePlayers.length > 0)!
  aTeamWithScorer.notablePlayers[0].seasonGoals = 19
  for (const s of adiv.standings) s.points = Math.floor(Math.random() * 40)
  const aAfter = applyAcademyPromotion(academy)
  const aSurvived = Object.values(aAfter.divisions).flatMap((d) => d.teams).find((t) => t.id === aTeamWithScorer.id)
  check(!!aSurvived, 'academy: the team with the scorer is still findable after the season rolls over')
  check(aSurvived!.notablePlayers[0].seasonGoals === 0, `academy: a notable player's goals reset to 0 at season rollover (was 19, is now ${aSurvived!.notablePlayers[0].seasonGoals})`)
}

console.log('\n[D] P85 — professional contract offers only generate during a real transfer window; academy invitations stay flexible')
{
  const { checkForOffers, isTransferWindowOpen } = await import('../src/engine/scouting')

  check(isTransferWindowOpen(20) === true, 'week 20 (mid-season window) is open')
  check(isTransferWindowOpen(42) === true, 'week 42 (run-in window) is open')
  check(isTransferWindowOpen(10) === false, 'week 10 (outside any window) is closed')
  check(isTransferWindowOpen(30) === false, 'week 30 (between windows) is closed')

  const readyWatcher = { club: { id: 'club-1', name: 'Test FC', short: 'TFC', ratings: { attack: 50, midfield: 50, defense: 50 }, prestige: 50, primaryColor: '#000', secondaryColor: '#fff', notablePlayers: [] }, interest: 90 }
  const baseState = { offers: [], watchers: [readyWatcher] }

  const outsideWindow = checkForOffers(baseState, 10, true, 20, 10) // isInAcademy=true -> professional kind, week 10 -> closed
  check(outsideWindow.offers.length === 0, 'a professional offer does NOT generate outside a transfer window, even with a ready watcher and eligible age')

  const insideWindow = checkForOffers(baseState, 20, true, 20, 20)
  check(insideWindow.offers.length === 1, 'a professional offer DOES generate inside a transfer window with the same ready watcher')

  const academyOutsideWindow = checkForOffers(baseState, 10, false, 15, 10) // isInAcademy=false -> academy kind, unaffected by window
  check(academyOutsideWindow.offers.length === 1, 'an academy invitation is NOT gated by the transfer window (youth registration stays flexible)')
}

console.log(fails === 0 ? '\n✅ AUDIT 21 PASSED' : `\n❌ AUDIT 21: ${fails} CHECK(S) FAILED`)
process.exit(fails ? 1 : 0)
