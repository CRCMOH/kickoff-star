// P74 — simXp.ts (the P49 tuning script) never exercised the phase-OVR-cap
// system added in P72: it used a flat CEILING=20 with no notion of "current
// career phase", so it couldn't tell us whether a real simulated career
// actually plateaus at the intended 60/73 OVR marks, undershoots them (XP
// wasted, growth feels dead long before the cap), or overshoots briefly
// before correcting. This is that same simulation, wired to the real
// maxAttrValueForPhaseCap/phaseCaCap functions instead of a fixed ceiling —
// so it tests the ACTUAL cap logic shipped in rating.ts, not a mock of it.
import { spendXp, trainingXpForDrill, matchXpEarned, type CompetitionTier } from '../src/engine/xp'
import { toOvr, phaseCaCap, maxAttrValueForPhaseCap, type CareerPhase } from '../src/engine/rating'
import type { ExecutionGrade } from '../src/engine/execution'
import { OUTFIELD_ATTRIBUTES } from '../src/types/attributes'

// P81 — was a hardcoded local copy of the attribute list, which went
// silently stale the moment the real list changed (12 -> 10 attributes) —
// it kept running without crashing, but its OVR readout no longer matched
// what the real game would compute. Importing the source of truth instead.
const OUTFIELD_ATTRS: string[] = OUTFIELD_ATTRIBUTES
const SESSION_GROUPS: Record<string, string[]> = {
  finishing: ['shooting', 'composure', 'pace'],
  passing: ['passing', 'vision', 'positioning'],
  physical: ['pace', 'strength', 'stamina'],
  defending: ['tackling', 'positioning', 'strength'],
  dribbling: ['dribbling', 'pace', 'composure'],
}
const SESSION_TYPES = Object.keys(SESSION_GROUPS)
const POSITION = 'ST'

function avgCA(values: Record<string, number>): number {
  return OUTFIELD_ATTRS.reduce((s, a) => s + values[a], 0) / OUTFIELD_ATTRS.length
}

function drawGrade(): ExecutionGrade {
  const r = Math.random()
  if (r < 0.12) return 'miss'
  if (r < 0.45) return 'ok'
  if (r < 0.85) return 'good'
  return 'perfect'
}

// spend against BOTH the potential ceiling (fixed at 19 here, same as
// spendAttributeXp's Math.max(current, potential-1) pattern) and the live
// phase-cap ceiling — exactly what the real store does — and take whichever
// is tighter, per attribute, every single spend.
function spendCapped(values: Record<string, number>, attr: string, xp: number, potentialCeiling: number, phase: CareerPhase): number {
  const phaseCeiling = maxAttrValueForPhaseCap(POSITION, values, attr, phaseCaCap(phase))
  const ceiling = Math.min(potentialCeiling, phaseCeiling)
  const r = spendXp(values[attr], xp, ceiling)
  return r.newLevel
}

function runCareer(seasons: { weeks: number; tier: CompetitionTier; phase: CareerPhase; label: string }[], startCA: number, potentialCeiling: number) {
  const values: Record<string, number> = {}
  for (const a of OUTFIELD_ATTRS) values[a] = startCA

  console.log(`\n=== starting raw CA ${avgCA(values).toFixed(2)} (OVR ~${toOvr(avgCA(values))}) — potential ceiling ${potentialCeiling} ===`)

  for (const season of seasons) {
    for (let week = 0; week < season.weeks; week++) {
      for (let t = 0; t < 2; t++) {
        const sType = SESSION_TYPES[(week * 2 + t) % SESSION_TYPES.length]
        const attrs = SESSION_GROUPS[sType]
        let pool = 0
        for (let d = 0; d < 3; d++) pool += trainingXpForDrill(drawGrade())
        const share = pool / attrs.length
        for (const a of attrs) values[a] = spendCapped(values, a, share, potentialCeiling, season.phase)
      }
      if (Math.random() < 0.9) {
        const rating = 5.5 + Math.random() * 3
        const goals = Math.random() < 0.25 ? 1 : 0
        const assists = Math.random() < 0.15 ? 1 : 0
        const pool = matchXpEarned(season.tier, rating, goals, assists)
        const share = pool / OUTFIELD_ATTRS.length
        for (const a of OUTFIELD_ATTRS) values[a] = spendCapped(values, a, share, potentialCeiling, season.phase)
      }
    }
    const ca = avgCA(values)
    const ovr = toOvr(ca)
    const capOvr = toOvr(phaseCaCap(season.phase))
    const flag = ovr >= capOvr ? '  <-- AT/OVER PHASE CAP' : ovr >= capOvr - 3 ? '  <-- approaching cap' : ''
    console.log(`${season.label} (${season.weeks}wk, ${season.tier}/${season.phase}) exit — raw CA ${ca.toFixed(2)} · OVR ~${ovr} (cap ${capOvr})${flag}`)
  }
  return values
}

console.log('=== LOW-POTENTIAL PLAYER (potential 14 — should plateau on HIS OWN ceiling well before the phase cap matters) ===')
runCareer([
  { weeks: 44, tier: 'grassroots', phase: 'grassroots-season', label: 'Grassroots S1' },
  { weeks: 44, tier: 'grassroots', phase: 'grassroots-season', label: 'Grassroots S2' },
  { weeks: 44, tier: 'grassroots', phase: 'grassroots-season', label: 'Grassroots S3' },
  { weeks: 44, tier: 'grassroots', phase: 'grassroots-season', label: 'Grassroots S4' },
], 2, 13)

console.log('\n=== HIGH-POTENTIAL WONDERKID (potential 19 — this is the one that actually tests the phase cap) ===')
runCareer([
  { weeks: 44, tier: 'grassroots', phase: 'grassroots-season', label: 'Grassroots S1' },
  { weeks: 44, tier: 'grassroots', phase: 'grassroots-season', label: 'Grassroots S2' },
  { weeks: 44, tier: 'grassroots', phase: 'grassroots-season', label: 'Grassroots S3' },
  { weeks: 44, tier: 'grassroots', phase: 'grassroots-season', label: 'Grassroots S4' },
  { weeks: 38, tier: 'academy', phase: 'academy', label: 'Academy S1' },
  { weeks: 38, tier: 'academy', phase: 'academy', label: 'Academy S2' },
  { weeks: 38, tier: 'academy', phase: 'academy', label: 'Academy S3' },
], 2, 18)
