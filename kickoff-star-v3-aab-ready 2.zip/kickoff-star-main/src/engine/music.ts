// Background music layer — separate from sfx.ts (which is synthesized).
// Uses a plain HTMLAudioElement so we don't have to decode the mp3 into an
// AudioBuffer or manage a MediaElementSourceNode. Respects the existing mute
// toggle, and exposes play()/pause() so callers (Career.tsx) can gate it off
// during match/training screens.
//
// P80 — Joel: "add this song to the game so that we have 2 songs." Was a
// single hardcoded TRACK_URL playing on an endless loop=true. Now a real
// (small) playlist: picks a random track to start, then advances to the
// next one when the current track ends rather than looping the same song
// forever, cycling back to the start once the list is exhausted.

import { isMuted } from './audio'

const TRACKS = [
  { name: 'Pulse of the Pitch', url: './audio/pulse-of-the-pitch.mp3' },
  { name: 'From Pavement to Green', url: './audio/from-pavement-to-green.mp3' },
]
const VOLUME = 0.35

let el: HTMLAudioElement | null = null
let wantsToPlay = false
let trackIndex = Math.floor(Math.random() * TRACKS.length)

function ensureEl(): HTMLAudioElement | null {
  if (typeof window === 'undefined') return null
  if (!el) {
    el = new Audio(TRACKS[trackIndex].url)
    el.loop = false
    el.volume = isMuted() ? 0 : VOLUME
    el.preload = 'auto'
    el.addEventListener('ended', () => {
      trackIndex = (trackIndex + 1) % TRACKS.length
      if (!el) return
      el.src = TRACKS[trackIndex].url
      if (wantsToPlay) void el.play().catch(() => { /* will retry on next call */ })
    })
  }
  return el
}

/** Start (or resume) background music. Safe to call repeatedly. */
export function playMusic(): void {
  wantsToPlay = true
  const a = ensureEl()
  if (!a) return
  a.volume = isMuted() ? 0 : VOLUME
  if (a.paused) {
    // play() can reject if not yet inside a user gesture on some mobile
    // browsers — that's fine, it'll succeed on the next gesture-triggered
    // call since wantsToPlay stays true.
    void a.play().catch(() => { /* will retry on next call */ })
  }
}

/** Pause background music (used during match/training screens). */
export function pauseMusic(): void {
  wantsToPlay = false
  if (el && !el.paused) el.pause()
}

/** Re-apply the current mute state to the music element (call from mute toggle). */
export function syncMusicMute(): void {
  if (!el) return
  el.volume = isMuted() ? 0 : VOLUME
  // If unmuting and playback was desired, make sure it's actually running.
  if (wantsToPlay && el.paused) void el.play().catch(() => { /* ignore */ })
}

/** The currently playing track's display name, for a "now playing" credit if ever wanted. */
export function currentTrackName(): string {
  return TRACKS[trackIndex].name
}
