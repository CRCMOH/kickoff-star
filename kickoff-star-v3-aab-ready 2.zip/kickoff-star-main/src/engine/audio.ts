// Audio layer — fully synthesized via WebAudio, so the PWA ships zero audio
// assets and works offline out of the box. Everything routes through one
// master gain with a persisted mute toggle.
//
// Mobile constraint: an AudioContext can only start from a user gesture, so
// the context is created lazily on the first sfx call (which is always a tap).

const MUTE_KEY = 'kickoff-star-muted'

let ctx: AudioContext | null = null
let master: GainNode | null = null

function ensureCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null
  try {
    if (!ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
      if (!AC) return null
      ctx = new AC()
      master = ctx.createGain()
      master.gain.value = isMuted() ? 0 : 0.5
      master.connect(ctx.destination)
    }
    if (ctx.state === 'suspended') void ctx.resume()
    return ctx
  } catch {
    return null
  }
}

export function isMuted(): boolean {
  try { return localStorage.getItem(MUTE_KEY) === '1' } catch { return false }
}

export function setMuted(muted: boolean): void {
  try { localStorage.setItem(MUTE_KEY, muted ? '1' : '0') } catch { /* private mode */ }
  if (master) master.gain.value = muted ? 0 : 0.5
}

export function toggleMuted(): boolean {
  const next = !isMuted()
  setMuted(next)
  return next
}

function tone(freq: number, start: number, duration: number, type: OscillatorType = 'sine', peak = 0.4) {
  const c = ensureCtx()
  if (!c || !master) return
  const osc = c.createOscillator()
  const gain = c.createGain()
  osc.type = type
  osc.frequency.value = freq
  const t = c.currentTime + start
  gain.gain.setValueAtTime(0.0001, t)
  gain.gain.exponentialRampToValueAtTime(peak, t + 0.015)
  gain.gain.exponentialRampToValueAtTime(0.0001, t + duration)
  osc.connect(gain).connect(master)
  osc.start(t)
  osc.stop(t + duration + 0.05)
}

function noise(start: number, duration: number, filterFreq: number, peak = 0.3) {
  const c = ensureCtx()
  if (!c || !master) return
  const len = Math.ceil(c.sampleRate * duration)
  const buf = c.createBuffer(1, len, c.sampleRate)
  const data = buf.getChannelData(0)
  for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1
  const src = c.createBufferSource()
  src.buffer = buf
  const filter = c.createBiquadFilter()
  filter.type = 'bandpass'
  filter.frequency.value = filterFreq
  const gain = c.createGain()
  const t = c.currentTime + start
  gain.gain.setValueAtTime(0.0001, t)
  gain.gain.exponentialRampToValueAtTime(peak, t + duration * 0.2)
  gain.gain.exponentialRampToValueAtTime(0.0001, t + duration)
  src.connect(filter).connect(gain).connect(master)
  src.start(t)
}

export const sfx = {
  /** Soft UI tap. */
  tap() { tone(660, 0, 0.06, 'sine', 0.12) },
  /** Referee's whistle — kickoff / full time. */
  whistle() {
    tone(2100, 0, 0.16, 'square', 0.10)
    tone(2400, 0.02, 0.14, 'square', 0.06)
  },
  /** Full-time double whistle. */
  fullTime() {
    tone(2100, 0, 0.12, 'square', 0.10)
    tone(2100, 0.18, 0.12, 'square', 0.10)
    tone(2100, 0.36, 0.30, 'square', 0.10)
  },
  /** Goal — crowd swell plus a rising hit. */
  goal() {
    noise(0, 1.1, 900, 0.35)
    tone(392, 0, 0.15, 'triangle', 0.3)
    tone(523, 0.12, 0.2, 'triangle', 0.35)
    tone(784, 0.26, 0.4, 'triangle', 0.4)
  },
  /** Opposition goal — flat crowd murmur, minor fall. */
  concede() {
    noise(0, 0.7, 500, 0.2)
    tone(330, 0, 0.2, 'triangle', 0.2)
    tone(262, 0.18, 0.35, 'triangle', 0.2)
  },
  /** Timing-bar perfect. */
  perfect() {
    tone(880, 0, 0.08, 'sine', 0.3)
    tone(1320, 0.07, 0.12, 'sine', 0.3)
  },
  /** Timing-bar miss. */
  miss() { tone(180, 0, 0.18, 'sawtooth', 0.18) },
  /** Achievement fanfare. */
  achievement() {
    tone(523, 0, 0.12, 'triangle', 0.3)
    tone(659, 0.11, 0.12, 'triangle', 0.3)
    tone(784, 0.22, 0.12, 'triangle', 0.3)
    tone(1047, 0.33, 0.35, 'triangle', 0.38)
  },
  // P84 — Joel: "does the game have the basic stuff like sound." Real gap:
  // a red card or an injury got a full-screen MomentFlash visual treatment
  // but ZERO sound beyond the ambient crowd bed — a card moment in a real
  // broadcast always has a sharp single whistle blast, and a bad injury
  // has a distinct, subdued character, not silence.
  /** A single sharp whistle blast — a card being shown. Shorter and blunter than the double-tone kickoff whistle. */
  card() { tone(2200, 0, 0.22, 'square', 0.14) },
  /** A low, uneasy tone — something's wrong, play has stopped for a reason that isn't good news. */
  injury() {
    tone(220, 0, 0.3, 'sine', 0.12)
    tone(180, 0.15, 0.4, 'sine', 0.1)
  },
  /** A crisp, positive stinger for a genuinely great save or tackle — distinct from the goal fanfare, more of a sharp "there it is" than a celebration. */
  bigMoment() {
    tone(660, 0, 0.1, 'triangle', 0.25)
    tone(880, 0.09, 0.18, 'triangle', 0.28)
  },
}

// ============================================================================
// P78 — CROWD AMBIENCE (Joel: "match ambience... make that more interesting").
// Before this, a live match had exactly four sounds total across 90 minutes:
// kickoff whistle, a goal/concede one-shot, and the full-time whistle — dead
// silence the rest of the time, regardless of how tense or one-sided the
// match was. This adds a continuous, momentum-reactive crowd bed: a low
// murmur at rest that swells in volume and brightens in tone as momentum
// swings toward the player's team, plus a short "intake of breath" swell for
// a good or clear chance. All synthesized (filtered looped noise), same
// zero-asset approach as the rest of this file, so it works offline exactly
// like the one-shot sfx already do.
// ============================================================================

let crowdSource: AudioBufferSourceNode | null = null
let crowdGain: GainNode | null = null
let crowdFilter: BiquadFilterNode | null = null

const CROWD_BASE_GAIN = 0.028
const CROWD_PEAK_GAIN = 0.12

function clamp(v: number, lo: number, hi: number) { return Math.max(lo, Math.min(hi, v)) }

function buildCrowdBed(c: AudioContext): AudioBufferSourceNode {
  // A few seconds of filtered noise, looped — a real stadium recording
  // would be nicer, but this reads as a genuine low crowd murmur rather
  // than obvious static once band-passed and kept quiet.
  const duration = 4
  const len = Math.ceil(c.sampleRate * duration)
  const buf = c.createBuffer(1, len, c.sampleRate)
  const data = buf.getChannelData(0)
  let last = 0
  for (let i = 0; i < len; i++) {
    // a touch of low-pass smoothing on the raw noise so it murmurs instead
    // of hissing — cheaper than a second BiquadFilterNode for this
    const raw = Math.random() * 2 - 1
    last = last * 0.96 + raw * 0.04
    data[i] = last
  }
  const src = c.createBufferSource()
  src.buffer = buf
  src.loop = true
  return src
}

/** Start the ambient crowd bed. Safe to call repeatedly — a second call while one is already running is a no-op. */
export function startCrowdAmbience(): void {
  const c = ensureCtx()
  if (!c || !master || crowdSource) return
  const src = buildCrowdBed(c)
  const filter = c.createBiquadFilter()
  filter.type = 'bandpass'
  filter.frequency.value = 550
  filter.Q.value = 0.5
  const gain = c.createGain()
  gain.gain.value = isMuted() ? 0 : CROWD_BASE_GAIN
  src.connect(filter).connect(gain).connect(master)
  src.start()
  crowdSource = src
  crowdFilter = filter
  crowdGain = gain
}

/** Stop and fully release the ambient crowd bed — call on match end / screen unmount. */
export function stopCrowdAmbience(): void {
  if (crowdSource) {
    try { crowdSource.stop() } catch { /* already stopped */ }
    crowdSource.disconnect()
    crowdSource = null
  }
  if (crowdFilter) { crowdFilter.disconnect(); crowdFilter = null }
  if (crowdGain) { crowdGain.disconnect(); crowdGain = null }
}

/**
 * Drive the crowd bed's volume/brightness from live match momentum (-10..10).
 * Momentum toward the player's team reads as anticipation building in the
 * home end — louder and a touch brighter, not just louder.
 */
export function setCrowdMomentum(momentum: number): void {
  const c = ensureCtx()
  if (!c || !crowdGain || !crowdFilter) return
  const norm = clamp((momentum + 10) / 20, 0, 1)
  const targetGain = isMuted() ? 0 : CROWD_BASE_GAIN + norm * (CROWD_PEAK_GAIN - CROWD_BASE_GAIN)
  crowdGain.gain.setTargetAtTime(targetGain, c.currentTime, 0.6)
  crowdFilter.frequency.setTargetAtTime(500 + norm * 450, c.currentTime, 0.6)
}

/** A short, sharper swell for a genuine chance — the crowd catching its breath, released win-or-not by whatever sound plays next (goal/miss/save). */
export function crowdChanceSwell(tier: 'half' | 'good' | 'clear'): void {
  const c = ensureCtx()
  if (!c || !master) return
  const peak = tier === 'clear' ? 0.16 : tier === 'good' ? 0.10 : 0.06
  const gain = c.createGain()
  const t = c.currentTime
  gain.gain.setValueAtTime(0.0001, t)
  gain.gain.exponentialRampToValueAtTime(isMuted() ? 0.0001 : peak, t + 0.5)
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.6)
  const filter = c.createBiquadFilter()
  filter.type = 'bandpass'
  filter.frequency.value = 900
  filter.Q.value = 0.7
  const src = buildCrowdBed(c)
  src.connect(filter).connect(gain).connect(master)
  src.start(t)
  src.stop(t + 1.7)
}
