// ============================================================================
// PHASE 49 — XP-BASED ATTRIBUTE PROGRESSION (engine layer only)
//
// Joel's design, agreed before any code: attributes are no longer grown by an
// automatic per-drill nudge. They're grown by spending XP the player earns,
// which the player allocates themselves. Two pools:
//   - TRAINING XP is restricted to exactly the attributes that session's
//     drills tested (SESSION_ATTRIBUTES already encodes this — was sitting
//     unused for this exact purpose).
//   - MATCH XP is universal — "you used everything," goes anywhere.
// No hard per-attribute cap. The brake is an ESCALATING COST CURVE: going
// from 80→90 in one attribute costs the same as spreading 40→50 across six
// different ones. Specialisation is allowed, but expensive — which is also
// exactly what produces the "90 shooting, 20 heading" identity Joel wants.
//
// This file is deliberately standalone and UI-free. Per the agreed build
// order: (1) this engine as data/logic, (2) simulate full careers and tune
// the constants against real measured outcomes, (3) only then build the
// allocation screen and wire it into training/match resolution.
// ============================================================================
import type { OutfieldAttribute, GoalkeeperAttribute } from '../types/attributes'
import type { ExecutionGrade } from './execution'

export type AttributeKey = OutfieldAttribute | GoalkeeperAttribute

// ---------------------------------------------------------------------------
// THE COST CURVE — XP required to gain +1 full level, by current level band.
//
// P49 CORRECTION: attributes in this codebase are internally on a 1-20
// scale (see rating.ts toOvr() — the 1-99 "OVR" ring is a DISPLAY mapping
// computed FROM the raw 1-20 value, floor ~33). The curve below is scaled
// for the real 1-20 range, not a mistaken 1-99 assumption.
// ---------------------------------------------------------------------------
// P75 — REBALANCED against the P72 phase-OVR-cap system. Simulated the
// actual best-case grassroots career (perfect training every session, a 9.5
// rating with a goal+assist every single week, real starting attributes
// from PlayerCreation.tsx) and found the OLD curve let a max-effort player
// hit the OVR60 cap by week 70 of the fixed 176-week (4-season) grassroots
// phase — 60% of the ENTIRE PHASE with zero possible growth even at max
// effort, because XP kept being earned with nowhere left to spend it.
// Grassroots length is fixed (types/player.ts: GrassrootsSeason is hard-
// capped 1|2|3|4), so that dead time couldn't be waited out or shortened.
//
// Fix: scale the cost curve up by 2.4x (found by search — the exact point
// where best-case play lands the cap at week 163/176, with a small margin
// rather than a razor's edge; 2.42x already overshoots into "never reaches
// it within the phase", so this isn't a round number by coincidence, it's
// deliberately sat just inside the safe side of that cliff). This is a
// SPEND-side fix, not an earn-side one — the exact per-match XP formula
// (5.0 rating = 400xp, +100/point, +50/goal, etc.) stays exactly as
// spec'd and already locked by a regression test; growing an attribute now
// just costs more of that same XP, at every level.
// P81 — RE-CALIBRATED after the attribute-count reduction (12 -> 10, see
// types/attributes.ts). This is a second, independent rebalance on top of
// P75's: the same weekly training/match XP pool now divides across FEWER
// attributes, which pushes each one into the game's more expensive cost
// bands sooner — for the SAME total XP earned, less total average level is
// reached than before, because more of it gets "spent" crossing into
// pricier territory per attribute instead of staying spread thin across
// more attributes in the cheap early bands. Concretely: after only the
// attribute-count change (no cost adjustment), the exact best-case-grassroots
// simulation from P75 stopped reaching the OVR60 cap AT ALL within the fixed
// 176-week phase — found via the same search methodology as P75, landing on
// a stable plateau (best-case hits the cap at week 123/176, ~30% margin,
// not a razor's-edge cliff like some nearby values were).
const COST_BANDS: { below: number; cost: number }[] = [
  { below: 6, cost: 1368 },
  { below: 10, cost: 3648 },
  { below: 13, cost: 8208 },
  { below: 16, cost: 18240 },
  { below: 18, cost: 41040 },
  { below: Infinity, cost: 82080 },
]

export function xpCostForLevel(currentLevel: number): number {
  for (const band of COST_BANDS) if (currentLevel < band.below) return band.cost
  return COST_BANDS[COST_BANDS.length - 1].cost
}

// P55 — real structural finding, not a tuning tweak: computeCurrentAbility's
// weighted OVR average reads only 4 GK attributes (reflexes/handling/
// gkPositioning/distribution) vs 12 for an outfield player. The cost curve
// above was position-agnostic, so the exact same amount of earned XP moved
// a keeper's OVR roughly 3x faster than an outfield player's — confirmed by
// simulation: a GK reached OVR 86 in the same 6 years an outfield player
// reached 76, with identical earning rates. This isn't about how the XP is
// SPENT (a real player choosing where to put it doesn't change how many
// attributes the weighted average reads) — it's structural, so the fix
// belongs in the cost curve itself.
export function positionCostMultiplier(isGoalkeeper: boolean): number {
  return isGoalkeeper ? 3 : 1
}

// ---------------------------------------------------------------------------
// SPENDING — continuous, not level-snapped. Attributes are already stored as
// decimals (e.g. 8.2), so XP spending fills the fractional part smoothly —
// this IS the progress bar Joel described: the fractional part of the level
// literally is how full the bar is. Correctly handles a pool big enough to
// cross more than one cost-band boundary in a single spend.
// ---------------------------------------------------------------------------
export interface SpendResult {
  newLevel: number
  xpUsed: number
  leftover: number
  levelsCrossed: number // how many whole-number boundaries were crossed — drives the "flash + reset" UI moment
}

export function spendXp(startLevel: number, xpPool: number, ceiling: number): SpendResult {
  const EPS = 1e-9
  let level = startLevel
  let remaining = Math.max(0, xpPool)
  let levelsCrossed = 0
  while (remaining > EPS && level < ceiling - EPS) {
    const bandFloor = Math.floor(level)
    const cost = xpCostForLevel(bandFloor)
    const stepTo = Math.min(bandFloor + 1, ceiling)
    const xpToReachStep = cost * (stepTo - level)
    if (remaining + EPS >= xpToReachStep) {
      remaining -= xpToReachStep
      level = stepTo
      if (Math.abs(stepTo - Math.floor(stepTo)) < EPS) levelsCrossed += 1
    } else {
      level += remaining / cost
      remaining = 0
    }
  }
  return {
    newLevel: Math.round(level * 100) / 100,
    xpUsed: Math.max(0, xpPool - remaining),
    leftover: Math.round(remaining * 100) / 100,
    levelsCrossed,
  }
}

// ---------------------------------------------------------------------------
// EARNING — training (restricted pool) and match (universal pool).
// ---------------------------------------------------------------------------

/** Base XP per drill before the execution multiplier. Tuned in P49 sim pass. */
export const XP_PER_DRILL_BASE = 60

/**
 * P49 fix for the "perfect but missed" complaint: execution grade barely
 * moves the football outcome (±14%, see EXECUTION_SWING) but now IS the
 * primary driver of how much you grow from the attempt. A perfect strike
 * that gets saved still earns full development credit — you did your job
 * correctly even when the situation didn't reward you for it. This is what
 * stops the mini-game from feeling like it's lying about what it measures.
 */
export const EXECUTION_XP_MULTIPLIER: Record<ExecutionGrade, number> = {
  miss: 0.5,
  ok: 0.8,
  good: 1.2,
  perfect: 1.6,
}

/**
 * Training drills (decision-card taps and mini-games) produce a 0-1 quality
 * ratio, not a raw ExecutionGrade the way a match TimingBar does. This maps
 * that ratio onto the same grade vocabulary so trainingXpForDrill can be
 * reused for both — one XP formula, not two.
 */
export function gradeFromRatio(ratio: number): ExecutionGrade {
  if (ratio >= 0.85) return 'perfect'
  if (ratio >= 0.55) return 'good'
  if (ratio >= 0.25) return 'ok'
  return 'miss'
}

export function trainingXpForDrill(grade: ExecutionGrade): number {
  return Math.round(XP_PER_DRILL_BASE * EXECUTION_XP_MULTIPLIER[grade])
}

export type CompetitionTier = 'grassroots' | 'academy' | 'cup' | 'international'

/**
 * P70 — MATCH XP, FULLY SPEC'D (Joel: "exp needs to be based on something...
 * not just random numbers after the game"). Every number below is a fixed
 * constant, and matchXpEarned is a pure function of rating + your match
 * stats — same inputs always produce the same XP, nothing is rolled.
 *
 * BASELINE: rating 5.0 is the reference point and is worth RATING_BASE_XP.
 * Every full rating point above or below adds/removes RATING_STEP_XP,
 * linearly — so 5.0=400, 6.0=500, 7.0=600, 8.0=700, and so on. A poor game
 * (below 5.0) still earns something down to a floor of 0, it's never negative.
 *
 * STAT BONUSES: flat XP per contribution, independent of rating or tier.
 * A 7.0 with 1 goal is exactly 600 + 50 = 650, as spec'd.
 */
export const RATING_BASELINE = 5.0
export const RATING_BASE_XP = 400
export const RATING_STEP_XP = 100

export function ratingBaseXp(rating: number): number {
  return Math.max(0, Math.round(RATING_BASE_XP + (rating - RATING_BASELINE) * RATING_STEP_XP))
}

export const XP_GOAL_BONUS = 50
export const XP_ASSIST_BONUS = 40
export const XP_TACKLE_BONUS = 20
export const XP_INTERCEPTION_BONUS = 15
export const XP_HEADER_BONUS = 10
export const XP_KEY_PASS_BONUS = 15
export const XP_SAVE_BONUS = 30

/** A bigger stage still counts for something, but additively — never multiplies the baseline, so the rating+goal formula above is exact at every tier. */
export const TIER_XP_BONUS: Record<CompetitionTier, number> = {
  grassroots: 0,
  academy: 50,
  cup: 100,
  international: 200,
}

/**
 * P75 — Joel: "playing in big matches and in a higher division makes you
 * gain higher exp." A Division 1 grassroots fixture is a bigger, harder
 * stage than a Division 3 one even though both are the same competition
 * tier — this rewards that separately from TIER_XP_BONUS, which only
 * distinguishes grassroots/academy/cup/international from each other, not
 * divisions within grassroots or academy. Division 1 = tier 1 = top flight,
 * so LOWER numbers get the BIGGER bonus.
 */
export const DIVISION_XP_BONUS: Record<1 | 2 | 3, number> = {
  1: 60,
  2: 25,
  3: 0,
}

export interface MatchXpStats {
  tackle?: number
  interception?: number
  header?: number
  keyPass?: number
  save?: number
}

export interface XpBreakdownItem {
  label: string
  detail: string
  xp: number
}

const TIER_DISPLAY_LABEL: Record<CompetitionTier, string> = {
  grassroots: 'Grassroots Football',
  academy: 'Academy Football',
  cup: 'Cup Match',
  international: 'International Cap',
}

/**
 * P82 — Joel: "before the exp thingy pops up there should be a screen that
 * shows the player how they got that exp... it should also look cool."
 * Single source of truth for the match-XP formula: every itemized line
 * here is exactly what feeds the total, in the same order it's earned, so
 * the breakdown screen can never drift from what matchXpEarned() actually
 * returns — matchXpEarned is now DERIVED from this, not a parallel
 * calculation that could quietly disagree with it.
 */
export function matchXpBreakdown(
  tier: CompetitionTier,
  rating: number,
  goals: number,
  assists: number,
  stats?: MatchXpStats,
  divisionTier?: 1 | 2 | 3
): XpBreakdownItem[] {
  const items: XpBreakdownItem[] = []

  items.push({ label: 'Match Rating', detail: `${rating.toFixed(1)} rating`, xp: ratingBaseXp(rating) })

  if (TIER_XP_BONUS[tier] > 0) {
    items.push({ label: TIER_DISPLAY_LABEL[tier], detail: 'stage bonus', xp: TIER_XP_BONUS[tier] })
  }
  if (divisionTier !== undefined && DIVISION_XP_BONUS[divisionTier] > 0) {
    items.push({ label: `Division ${divisionTier}`, detail: 'higher stage, bigger reward', xp: DIVISION_XP_BONUS[divisionTier] })
  }
  if (goals > 0) {
    items.push({ label: 'Goals', detail: `${goals} × ${XP_GOAL_BONUS}xp`, xp: goals * XP_GOAL_BONUS })
  }
  if (assists > 0) {
    items.push({ label: 'Assists', detail: `${assists} × ${XP_ASSIST_BONUS}xp`, xp: assists * XP_ASSIST_BONUS })
  }
  if (stats?.save) {
    items.push({ label: 'Saves', detail: `${stats.save} × ${XP_SAVE_BONUS}xp`, xp: stats.save * XP_SAVE_BONUS })
  }
  if (stats?.tackle) {
    items.push({ label: 'Tackles', detail: `${stats.tackle} × ${XP_TACKLE_BONUS}xp`, xp: stats.tackle * XP_TACKLE_BONUS })
  }
  if (stats?.interception) {
    items.push({ label: 'Interceptions', detail: `${stats.interception} × ${XP_INTERCEPTION_BONUS}xp`, xp: stats.interception * XP_INTERCEPTION_BONUS })
  }
  if (stats?.header) {
    items.push({ label: 'Headers Won', detail: `${stats.header} × ${XP_HEADER_BONUS}xp`, xp: stats.header * XP_HEADER_BONUS })
  }
  if (stats?.keyPass) {
    items.push({ label: 'Key Passes', detail: `${stats.keyPass} × ${XP_KEY_PASS_BONUS}xp`, xp: stats.keyPass * XP_KEY_PASS_BONUS })
  }

  return items
}

export function matchXpEarned(
  tier: CompetitionTier,
  rating: number,
  goals: number,
  assists: number,
  stats?: MatchXpStats,
  divisionTier?: 1 | 2 | 3
): number {
  return Math.round(matchXpBreakdown(tier, rating, goals, assists, stats, divisionTier).reduce((s, i) => s + i.xp, 0))
}
