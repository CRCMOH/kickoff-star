import type { Player } from '../types/player'
import { effectiveValues } from './economy'

// Derive a live 1-20 Current Ability from actual attributes, weighted by position.
// This recomputes every render so growth is always reflected (fixes frozen-CA bug).

const OUTFIELD_WEIGHTS: Record<string, Record<string, number>> = {
  ST: { shooting: 3, composure: 2, dribbling: 2, pace: 3, positioning: 2, passing: 1, strength: 1, stamina: 1, vision: 1, tackling: 0.3 },
  WG: { dribbling: 3, pace: 5, shooting: 1.5, passing: 1.5, vision: 1, composure: 1, stamina: 1, positioning: 2, strength: 0.5, tackling: 0.3 },
  WM: { passing: 2.5, dribbling: 2, vision: 2, stamina: 2, pace: 2.5, positioning: 2.5, tackling: 1, composure: 1, shooting: 1, strength: 1 },
  CM: { passing: 3, vision: 2.5, positioning: 3.5, composure: 2, tackling: 1.5, stamina: 1.5, dribbling: 1, strength: 1, shooting: 1, pace: 2 },
  CB: { tackling: 3, positioning: 5, strength: 2.5, composure: 1.5, pace: 2.5, passing: 1, stamina: 1, vision: 0.5, shooting: 0.3, dribbling: 0.3 },
  FB: { tackling: 2, positioning: 3, pace: 4, stamina: 2.5, dribbling: 1.5, passing: 1.5, strength: 1.5, composure: 1, vision: 1, shooting: 0.5 },
}

const GK_WEIGHTS: Record<string, number> = { reflexes: 3, handling: 2.5, gkPositioning: 2.5, distribution: 1.5 }

export function computeCurrentAbility(player: Player): number {
  // P29: equipment boosts apply through effectiveValues (capped at potential)
  const values = effectiveValues(player)
  const weights = player.position === 'GK' ? GK_WEIGHTS : OUTFIELD_WEIGHTS[player.position]
  if (!weights) return 8
  let sum = 0, wTotal = 0
  for (const [attr, w] of Object.entries(weights)) {
    sum += (values[attr] ?? 0) * w
    wTotal += w
  }
  return wTotal > 0 ? Math.round((sum / wTotal) * 10) / 10 : 8
}

// Convert 1-20 to a 1-99 "OVR" display for the ring, since players expect that scale.
// P50 — widened the floor. Was 30+(ca/20)*69, floor ~33, which meant a
// literal 20s starting OVR was mathematically unreachable regardless of how
// poor a trial went. Checked every consumer first: only display screens
// (PlayerTab/HomeTab/CareerEnd) and this file read it — scouting and
// contract logic all read the raw 1-20 attributes directly, so recalibrating
// the display mapping is safe. Now: ca=1 -> ~24, ca=20 -> 99.
export function toOvr(ca: number): number {
  return Math.round(20 + (ca / 20) * 79) // maps 1-20 -> ~24-99
}

// ============================================================================
// P72 — PHASE OVR CAPS (Joel: "the goal of the game is for player overall to
// not pass a certain mark from grassroots to academy and from academy to
// pro... the exp should be calculated using that info").
//
// Each phase of the career has a hard ceiling on the player's overall — you
// simply cannot out-grind your way to a 90 OVR while still turning out for
// Sunday League U16s. This is enforced at the XP-spend point (see
// spendAttributeXp in careerStore.ts): once the player's weighted CA would
// put their OVR at or above the cap for their CURRENT phase, no further XP
// converts into that attribute until they move up a phase. XP itself is
// never wasted or clamped at the earning step — only spending into a
// phase-capped ceiling is restricted, exactly like the existing potential
// ceiling already works.
// ============================================================================
export type CareerPhase = 'grassroots-trials' | 'grassroots-season' | 'academy'

/** Max OVR (1-99 display scale) obtainable while still in this phase of the career. */
export const PHASE_OVR_CAP: Record<CareerPhase, number> = {
  'grassroots-trials': 60,
  'grassroots-season': 60,
  'academy': 73,
}

/** Inverse of toOvr() — the raw 1-20 CA value a given display OVR corresponds to. */
export function ovrToCa(ovr: number): number {
  return ((ovr - 20) / 79) * 20
}

/** The raw-CA ceiling for a phase, ready to compare directly against computeCurrentAbility(). */
export function phaseCaCap(phase: CareerPhase | string): number {
  const cap = PHASE_OVR_CAP[phase as CareerPhase]
  return cap !== undefined ? ovrToCa(cap) : 20 // no cap once through academy (turning pro ends the sim career)
}

/**
 * Given a proposed set of attribute values, how far can ONE attribute (attr)
 * still rise before the player's weighted CA hits the phase cap? Returns the
 * highest value that attribute can take — spendAttributeXp uses this as an
 * extra ceiling alongside the existing potential-based one, so the tighter
 * of the two always wins.
 */
export function maxAttrValueForPhaseCap(
  position: string,
  values: Record<string, number>,
  attr: string,
  capCa: number
): number {
  const weights = position === 'GK' ? GK_WEIGHTS : OUTFIELD_WEIGHTS[position]
  const w = weights?.[attr] ?? 0
  const current = values[attr] ?? 0
  if (!weights || w <= 0) return 20 // attribute doesn't feed this position's CA at all — nothing to cap
  let sum = 0, wTotal = 0
  for (const [a, wt] of Object.entries(weights)) {
    sum += (values[a] ?? 0) * wt
    wTotal += wt
  }
  if (wTotal <= 0) return 20
  // currentCA + (w * delta) / wTotal <= capCa  =>  delta <= (capCa * wTotal - sum) / w
  const maxDelta = (capCa * wTotal - sum) / w
  return Math.max(current, current + maxDelta)
}

/**
 * Convenience wrapper for the AllocationScreen call sites: builds the full
 * attr -> ceiling map in one shot, for whichever attrs are on offer.
 */
export function phaseCeilingsFor(position: string, values: Record<string, number>, phase: CareerPhase | string, attrs: string[]): Record<string, number> {
  const cap = phaseCaCap(phase)
  const out: Record<string, number> = {}
  for (const a of attrs) out[a] = maxAttrValueForPhaseCap(position, values, a, cap)
  return out
}
