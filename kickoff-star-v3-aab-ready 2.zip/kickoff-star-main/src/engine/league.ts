import { rand } from './rng'
import { generateTeam, generatePlayerTeam, type Team, type NotablePlayer, type NotablePosition } from './teams'
import { generateRoundRobin } from './competitions'

// ============================================================================
// GRASSROOTS SEASON LOOP (Phase 8) — locked world scope:
// 3 divisions of 10 teams each, promotion/relegation, prestige gate per division.
// Fixtures are single round-robin (9 matches/team) to leave room for school/cups/
// training in a 34-week season, per the earlier build-order tradeoff discussion.
// ============================================================================

export type DivisionTier = 1 | 2 | 3 // 1 = top division

export interface LeagueStanding {
  teamId: string
  teamName: string
  teamShort: string
  played: number
  won: number
  drawn: number
  lost: number
  goalsFor: number
  goalsAgainst: number
  points: number
}

export interface Fixture {
  id: string
  week: number
  homeTeamId: string
  awayTeamId: string
  played: boolean
  homeGoals: number | null
  awayGoals: number | null
}

export interface Division {
  tier: DivisionTier
  teams: Team[]
  standings: LeagueStanding[]
  fixtures: Fixture[]
}

export interface LeagueWorld {
  divisions: Record<DivisionTier, Division>
  playerDivision: DivisionTier
  playerTeamId: string
}

const DIVISION_PRESTIGE_RANGE: Record<DivisionTier, [number, number]> = {
  1: [5, 8],
  2: [3, 5],
  3: [1, 3],
}

function initStanding(team: Team): LeagueStanding {
  return { teamId: team.id, teamName: team.name, teamShort: team.short, played: 0, won: 0, drawn: 0, lost: 0, goalsFor: 0, goalsAgainst: 0, points: 0 }
}

// Fixture generation now delegates to the shared generic round-robin generator
// (engine/competitions.ts) so every competition in the game uses the same
// circle-method math. legs=1 today (single round-robin, unchanged behaviour);
// P18 bumps this to legs=2 for the 12-team home-and-away Sunday League.
function generateFixtures(teams: Team[], legs: 1 | 2 = 1): Fixture[] {
  return generateRoundRobin(teams.map((t) => t.id), legs).map((f) => ({
    id: f.id,
    week: f.round,
    homeTeamId: f.homeTeamId,
    awayTeamId: f.awayTeamId,
    played: f.played,
    homeGoals: f.homeGoals,
    awayGoals: f.awayGoals,
  }))
}

function initDivision(tier: DivisionTier, playerTeam?: Team): Division {
  const [lo, hi] = DIVISION_PRESTIGE_RANGE[tier]
  const teams: Team[] = []
  if (playerTeam) teams.push(playerTeam)
  while (teams.length < 12) {
    teams.push(generateTeam(lo + Math.floor(rand() * (hi - lo + 1))))
  }
  return { tier, teams, standings: teams.map(initStanding), fixtures: generateFixtures(teams, 2) }
}

// Player starts in Division 3 (lowest) per typical grassroots entry point.
export function initLeagueWorld(playerTeamName: string): LeagueWorld {
  const playerTeam = generatePlayerTeam(playerTeamName, 2)
  const div3 = initDivision(3, playerTeam)
  const div2 = initDivision(2)
  const div1 = initDivision(1)
  return {
    divisions: { 1: div1, 2: div2, 3: div3 },
    playerDivision: 3,
    playerTeamId: playerTeam.id,
  }
}

function updateStandingsFromResult(standings: LeagueStanding[], homeId: string, awayId: string, hg: number, ag: number): LeagueStanding[] {
  return standings.map((s) => {
    if (s.teamId === homeId) {
      const won = hg > ag, drawn = hg === ag, lost = hg < ag
      return { ...s, played: s.played + 1, won: s.won + (won ? 1 : 0), drawn: s.drawn + (drawn ? 1 : 0), lost: s.lost + (lost ? 1 : 0), goalsFor: s.goalsFor + hg, goalsAgainst: s.goalsAgainst + ag, points: s.points + (won ? 3 : drawn ? 1 : 0) }
    }
    if (s.teamId === awayId) {
      const won = ag > hg, drawn = ag === hg, lost = ag < hg
      return { ...s, played: s.played + 1, won: s.won + (won ? 1 : 0), drawn: s.drawn + (drawn ? 1 : 0), lost: s.lost + (lost ? 1 : 0), goalsFor: s.goalsFor + ag, goalsAgainst: s.goalsAgainst + hg, points: s.points + (won ? 3 : drawn ? 1 : 0) }
    }
    return s
  })
}

export function sortStandings(standings: LeagueStanding[]): LeagueStanding[] {
  return [...standings].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points
    const gdA = a.goalsFor - a.goalsAgainst, gdB = b.goalsFor - b.goalsAgainst
    if (gdB !== gdA) return gdB - gdA
    return b.goalsFor - a.goalsFor
  })
}

// Record the player's own match result into their division.
export function recordPlayerMatchResult(world: LeagueWorld, opponentId: string, playerScored: number, opponentScored: number, playerWasHome: boolean): LeagueWorld {
  const division = world.divisions[world.playerDivision]
  const homeId = playerWasHome ? world.playerTeamId : opponentId
  const awayId = playerWasHome ? opponentId : world.playerTeamId
  const hg = playerWasHome ? playerScored : opponentScored
  const ag = playerWasHome ? opponentScored : playerScored

  const fixtures = division.fixtures.map((f) =>
    !f.played && f.homeTeamId === homeId && f.awayTeamId === awayId
      ? { ...f, played: true, homeGoals: hg, awayGoals: ag }
      : f
  )
  const standings = updateStandingsFromResult(division.standings, homeId, awayId, hg, ag)
  return { ...world, divisions: { ...world.divisions, [world.playerDivision]: { ...division, fixtures, standings } } }
}

function simpleScore(attack: number, defense: number): number {
  const expected = Math.max(0.2, (attack - defense) / 40 + 1.3)
  let goals = 0
  let p = rand() * expected * 1.8
  while (p > 1) { goals++; p -= 1 }
  if (rand() < (p % 1)) goals++
  return Math.min(goals, 7)
}

// Batch-sim a specific fixture round (Tier 2/3 NPC depth — lightweight), skipping any
// fixture involving the player's own team (that's simmed via the real match engine).
// Takes an explicit round number rather than inferring "lowest unplayed round" — this
// matters because if the player misses their own fixture (e.g. injured on a matchday),
// that single fixture staying unplayed must never block the REST of the division from
// progressing through later rounds; an inferred-minimum approach would stall forever.
// includePlayerTeam: sim the player's own fixture too — used when the player
// missed their matchday (injury), so the season never carries a permanently
// unplayed fixture. Sims all rounds <= round (self-heals any backlog).
// P64 — which notable player scored a given goal. Weighted toward the
// striker (most goals should come from the front), but not exclusively —
// a midfielder or even a defender chips in sometimes, same spirit as the
// existing assist-picking weights in squad.ts. GK never scores.
export const SCORER_WEIGHT: Record<NotablePosition, number> = { ST: 3, CM: 1.2, CB: 0.4, GK: 0 }
export function pickScorer(players: NotablePlayer[]): NotablePlayer {
  const weights = players.map((p) => SCORER_WEIGHT[p.position])
  const total = weights.reduce((a, b) => a + b, 0)
  let roll = rand() * total
  for (let i = 0; i < players.length; i++) {
    roll -= weights[i]
    if (roll <= 0) return players[i]
  }
  return players[players.length - 1]
}
export function attributeGoals(team: Team, goals: number): Team {
  if (goals === 0 || team.notablePlayers.length === 0) return team
  const players = team.notablePlayers.map((p) => ({ ...p }))
  for (let i = 0; i < goals; i++) {
    const scorer = pickScorer(players)
    scorer.seasonGoals += 1
  }
  return { ...team, notablePlayers: players }
}

export function batchSimDivisionRound(division: Division, round: number, playerTeamId: string, includePlayerTeam = false): Division {
  const teamById = new Map(division.teams.map((t) => [t.id, t]))
  let standings = division.standings
  const fixtures = division.fixtures.map((f) => {
    if (f.played || f.week > round) return f
    if (!includePlayerTeam && (f.homeTeamId === playerTeamId || f.awayTeamId === playerTeamId)) return f
    const home = teamById.get(f.homeTeamId)
    const away = teamById.get(f.awayTeamId)
    if (!home || !away) return f
    const hg = simpleScore(home.ratings.attack, away.ratings.defense)
    const ag = simpleScore(away.ratings.attack, home.ratings.defense)
    standings = updateStandingsFromResult(standings, f.homeTeamId, f.awayTeamId, hg, ag)
    // Attribute each goal to a real notable player, keeping teamById in
    // sync so a team that plays (and scores) more than once in the same
    // round accumulates correctly rather than each fixture overwriting it.
    teamById.set(home.id, attributeGoals(home, hg))
    teamById.set(away.id, attributeGoals(away, ag))
    return { ...f, played: true, homeGoals: hg, awayGoals: ag }
  })
  return { ...division, teams: division.teams.map((t) => teamById.get(t.id) ?? t), fixtures, standings }
}

// End-of-season promotion/relegation. Top 2 promoted, bottom 2 relegated.
// Phase 18: zones re-derived for 12-team divisions (top 2 promoted, bottom 2
// relegated — positions 0/1 and 10/11 of a 12-team table, was 8/9 when this
// was written for 10 teams).
// P64 — the real current top scorer in a division, excluding the player's
// own team. Used to make the "Golden Boot rival" a genuine reflection of
// the simulated world (a real named player on a real, findable team) instead
// of a synthetic name drifting on its own random schedule.
export function topScorerInDivision(division: Division, excludeTeamId: string): { name: string; club: string; goals: number } | null {
  const candidates = division.teams
    .filter((t) => t.id !== excludeTeamId)
    .flatMap((t) => t.notablePlayers.map((p) => ({ name: p.name, club: t.name, goals: p.seasonGoals })))
    .filter((p) => p.goals > 0)
  if (candidates.length === 0) return null
  return candidates.sort((a, b) => b.goals - a.goals)[0]
}

export interface ScorerEntry {
  name: string
  club: string
  goals: number
  isPlayer: boolean
}

/**
 * P71 — the real division scorers table, WITH the player in it. Joel:
 * "player's goals should also be synced to the top goalscorer thingy so his
 * name also appears." topScorerInDivision() above deliberately excludes the
 * player's own team to find a genuine NPC rival — but that meant the player
 * was structurally invisible in his own division's scoring charts no matter
 * how many he scored. This merges the NPC notablePlayers with the player's
 * own live seasonGoals count into one sorted, rankable list.
 */
export function divisionScorers(
  division: Division,
  playerTeamId: string,
  playerName: string,
  playerSeasonGoals: number
): ScorerEntry[] {
  const playerTeam = division.teams.find((t) => t.id === playerTeamId)
  const npcEntries: ScorerEntry[] = division.teams.flatMap((t) =>
    t.notablePlayers.map((p) => ({ name: p.name, club: t.name, goals: p.seasonGoals, isPlayer: false }))
  )
  const ownEntry: ScorerEntry[] = playerTeam
    ? [{ name: playerName, club: playerTeam.name, goals: playerSeasonGoals, isPlayer: true }]
    : []
  return [...npcEntries, ...ownEntry]
    .filter((e) => e.goals > 0)
    .sort((a, b) => b.goals - a.goals)
}

// P84 — Joel: "does the game make football sense... AI players." Real bug
// found: buildDivisionFromTeams carries a team's full identity forward
// across a season boundary, including notablePlayers — but nobody ever
// reset their seasonGoals when doing so. The PLAYER's own seasonGoals
// correctly resets to 0 every new season (see careerStore.ts), but every
// AI team's "top scorer" just kept accumulating goals across every season
// of the whole career, forever — so the scorers table the player sees
// (engine/league.ts's divisionScorers) was showing 3 seasons of
// accumulated tally as if it were one season's form, real football never
// works this way. Fixed at the actual season boundary, in the one function
// every promoted/relegated/surviving team already passes through.
function resetSeasonalStats(teams: Team[]): Team[] {
  return teams.map((t) => ({ ...t, notablePlayers: t.notablePlayers.map((p) => ({ ...p, seasonGoals: 0 })) }))
}

/** Builds a division from an explicit team list (not randomly generated) — fresh standings and fixtures for a new season, real team identities carried forward. */
function buildDivisionFromTeams(tier: DivisionTier, teams: Team[]): Division {
  return { tier, teams: resetSeasonalStats(teams), standings: teams.map(initStanding), fixtures: generateFixtures(teams, 2) }
}

// P68 — the real, long-flagged gap from P64/66: every team other than the
// player's own got fully regenerated from scratch each season, regardless
// of how it actually finished — so "promotion/relegation" only ever
// existed for the one team the player controlled. This is the real fix:
// every one of the 36 teams across all 3 divisions is tracked by its
// actual final standing and moves (or stays) accordingly, carrying its
// real identity (name/colours/notablePlayers) forward into the new season.
// Team counts verified to balance exactly at every tier:
//   Div1 (12): 10 survive + 2 promoted from Div2 = 12
//   Div2 (12): 8 survive + 2 relegated from Div1 + 2 promoted from Div3 = 12
//   Div3 (12): 10 survive + 2 relegated from Div2 = 12
// The player's own team is no longer special-cased — it's just one of the
// 36 teams being moved/rescaled by this same generalized logic, which also
// means the P66 rescale-on-promotion fix now applies uniformly rather than
// only when the SPECIFIC team that moved happened to be the player's.
export function applyPromotionRelegation(world: LeagueWorld): LeagueWorld {
  const sorted1 = sortStandings(world.divisions[1].standings)
  const sorted2 = sortStandings(world.divisions[2].standings)
  const sorted3 = sortStandings(world.divisions[3].standings)

  const teamById = new Map<string, Team>()
  for (const div of Object.values(world.divisions)) for (const t of div.teams) teamById.set(t.id, t)
  const teamOf = (s: LeagueStanding) => teamById.get(s.teamId)!

  const div1Survivors = sorted1.slice(0, -2).map(teamOf)
  const div1Relegated = sorted1.slice(-2).map(teamOf)

  const div2Promoted = sorted2.slice(0, 2).map(teamOf)
  const div2Survivors = sorted2.slice(2, -2).map(teamOf)
  const div2Relegated = sorted2.slice(-2).map(teamOf)

  const div3Promoted = sorted3.slice(0, 2).map(teamOf)
  const div3Survivors = sorted3.slice(2).map(teamOf)

  // Same rescale fix as P66 — a team that changed tier gets a rating that
  // genuinely fits its new level, not whatever it happened to roll at
  // whatever tier it started this journey in.
  const promotedTo1 = div2Promoted.map((t) => rescaleTeamToRange(t, DIVISION_PRESTIGE_RANGE[1]))
  const relegatedTo2 = div1Relegated.map((t) => rescaleTeamToRange(t, DIVISION_PRESTIGE_RANGE[2]))
  const promotedTo2 = div3Promoted.map((t) => rescaleTeamToRange(t, DIVISION_PRESTIGE_RANGE[2]))
  const relegatedTo3 = div2Relegated.map((t) => rescaleTeamToRange(t, DIVISION_PRESTIGE_RANGE[3]))

  const newDiv1Teams = [...div1Survivors, ...promotedTo1]
  const newDiv2Teams = [...div2Survivors, ...relegatedTo2, ...promotedTo2]
  const newDiv3Teams = [...div3Survivors, ...relegatedTo3]

  const newPlayerDivision: DivisionTier =
    newDiv1Teams.some((t) => t.id === world.playerTeamId) ? 1
    : newDiv2Teams.some((t) => t.id === world.playerTeamId) ? 2
    : 3

  return {
    divisions: {
      1: buildDivisionFromTeams(1, newDiv1Teams),
      2: buildDivisionFromTeams(2, newDiv2Teams),
      3: buildDivisionFromTeams(3, newDiv3Teams),
    },
    playerDivision: newPlayerDivision,
    playerTeamId: world.playerTeamId,
  }
}

/** Re-rolls a team's ratings/prestige to a real value within the given prestige range, keeping identity (id/name/colors/notablePlayers) unchanged. Shared with academy.ts, which has its own different tier→prestige table. */
export function rescaleTeamToRange(team: Team, [lo, hi]: [number, number]): Team {
  const prestige = lo + Math.floor(rand() * (hi - lo + 1))
  const base = Math.min(90, Math.max(20, prestige * 9 + 15))
  const jitter = () => Math.round(base + (rand() - 0.5) * 20)
  const clampR = (v: number) => Math.min(95, Math.max(15, v))
  return {
    ...team,
    prestige,
    ratings: { attack: clampR(jitter()), midfield: clampR(jitter()), defense: clampR(jitter()) },
  }
}

export function divisionLabel(tier: DivisionTier): string {
  return tier === 1 ? 'Division 1' : tier === 2 ? 'Division 2' : 'Division 3'
}
