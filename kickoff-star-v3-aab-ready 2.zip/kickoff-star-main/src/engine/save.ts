import { get, set, del } from 'idb-keyval'
import type { Player } from '../types/player'
import type { CalendarState } from '../types/calendar'
import type { LeagueWorld } from './league'
import type { AcademyWorld } from './academy'
import type { CupWorld } from './cup'
import type { InternationalWorld } from './international'
import type { TrainingSession } from './training'
import type { TrainingIntensity } from './energy'

// Locked scope: local-only save data (IndexedDB), 3 save slots per device.
//
// SCHEMA VERSIONING (audit blocker fix): every save now carries schemaVersion
// so future shape changes migrate instead of silently corrupting careers.
//  v1 (implicit, no version field): player/calendar/league/academyLeague only
//  v2: + schemaVersion, cup worlds, international world
//  v3: + pendingTraining — P53 real bug: a training session's progress
//      (which drill you're on, XP earned so far) lived ONLY in local React
//      component state, never saved. A confirmed real playtest report: mid
//      training session on a phone, playing through itch's iframe embed,
//      the game reloaded (mobile browsers are far more prone to backgrounding
//      an iframe than a desktop tab) and the whole session silently restarted
//      from the first drill, wiping real progress with no warning. Now
//      checkpointed after every completed drill so a reload resumes instead
//      of restarting.
//  v4: P81 — attribute reduction (12 -> 10 outfield attributes). 'agility'
//      merged into 'pace', 'concentration' merged into 'positioning'. A v3
//      or earlier save's player.attributes.values still has the OLD keys —
//      without this migration, those values would just sit there as dead
//      weight (never read by computeCurrentAbility, which only iterates the
//      current 10-attribute list), silently discarding real progress a
//      player earned. Folded in via simple addition, same "sum-preserving"
//      merge used for the position weight tables in engine/rating.ts.
export const SAVE_SCHEMA_VERSION = 4

export type SaveSlotId = 0 | 1 | 2

export interface CupWorlds {
  schoolCup: CupWorld | null
  sundayCup: CupWorld | null
  academyLeagueCup: CupWorld | null
  academyKnockoutCup: CupWorld | null
}

export const EMPTY_CUPS: CupWorlds = { schoolCup: null, sundayCup: null, academyLeagueCup: null, academyKnockoutCup: null }

export interface PendingTrainingSnapshot {
  session: TrainingSession
  xpEarned: number
  energySpent: number
  intensity: TrainingIntensity
}

export interface SaveGame {
  schemaVersion: number
  slotId: SaveSlotId
  savedAt: string // ISO timestamp
  player: Player
  calendar: CalendarState
  league: LeagueWorld | null
  academyLeague: AcademyWorld | null
  cups: CupWorlds
  international: InternationalWorld | null
  pendingTraining: PendingTrainingSnapshot | null
}

const slotKey = (slot: SaveSlotId) => `kickoff-star-save-${slot}`

// Bring any older on-disk shape up to the current schema. v1 saves predate
// cups/internationals — they get empty worlds, which the store lazily
// initializes on the next week tick (batch-sim self-heal covers the missed rounds).
//
// P81 — restructured from early-return branches into a proper cascading
// chain. Real bug in the old shape: a v1 save's `if (schemaVersion < 2)`
// branch RETURNED immediately after only applying the v2 fix — it never
// fell through to the v3 pendingTraining fix, and now would have skipped
// the v4 attribute migration below entirely too. Every version's fix now
// applies in sequence regardless of how far behind the save is.
function migratePlayerAttributes(player: SaveGame['player']): SaveGame['player'] {
  const values = player?.attributes?.values as Record<string, number> | undefined
  if (!values) return player
  const hasLegacy = 'agility' in values || 'concentration' in values
  if (!hasLegacy) return player
  const next = { ...values }
  if ('agility' in next) {
    next.pace = (next.pace ?? 8) + next.agility
    delete next.agility
  }
  if ('concentration' in next) {
    next.positioning = (next.positioning ?? 8) + next.concentration
    delete next.concentration
  }
  return { ...player, attributes: { ...player.attributes, values: next } } as SaveGame['player']
}

function migrateSave(raw: SaveGame & { schemaVersion?: number }): SaveGame {
  let s: SaveGame = raw as SaveGame
  if (!raw.schemaVersion || raw.schemaVersion < 2) {
    s = {
      ...s,
      schemaVersion: 2,
      cups: s.cups ?? { ...EMPTY_CUPS },
      international: s.international ?? null,
      pendingTraining: null,
    }
  }
  if (s.schemaVersion < 3) {
    s = { ...s, schemaVersion: 3, pendingTraining: null }
  }
  if (s.schemaVersion < 4) {
    s = { ...s, schemaVersion: 4, player: migratePlayerAttributes(s.player) }
  }
  return { ...s, schemaVersion: SAVE_SCHEMA_VERSION }
}

export async function writeSave(save: SaveGame): Promise<void> {
  await set(slotKey(save.slotId), { ...save, schemaVersion: SAVE_SCHEMA_VERSION })
}

export async function readSave(slot: SaveSlotId): Promise<SaveGame | undefined> {
  const raw = await get(slotKey(slot))
  return raw ? migrateSave(raw) : undefined
}

export async function deleteSave(slot: SaveSlotId): Promise<void> {
  await del(slotKey(slot))
}

export async function listSaves(): Promise<(SaveGame | undefined)[]> {
  return Promise.all([0, 1, 2].map((slot) => readSave(slot as SaveSlotId)))
}
