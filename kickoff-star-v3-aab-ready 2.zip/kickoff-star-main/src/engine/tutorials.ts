import { useState } from 'react'

// P83 — Joel: "make sure every mini game the first time you play it it has
// like a tutorial message that explains to you what you actually have to
// do." A first-time player was dropped straight into a sweeping reticle
// with zero explanation of what "the gold zone" even means, for all 11
// distinct mechanics in the game. This is the tutorial content + the
// persistence layer (localStorage, since these aren't tied to any one save
// slot — the point is "have you personally ever seen this minigame before,"
// which should hold true across every career you start).

export type TutorialKey =
  | 'timing-bar' | 'shooting' | 'passing' | 'tackle' | 'dribble'
  | 'cross-header' | 'keeper' | 'rondo' | 'targets' | 'sprint' | 'street'

export interface TutorialContent {
  title: string
  body: string
}

export const TUTORIALS: Record<TutorialKey, TutorialContent> = {
  'timing-bar': {
    title: 'Timing Bar',
    body: 'A bar sweeps back and forth. Tap when the marker sits inside the gold zone — the closer to dead center, the better your result. Too early or too late and it counts as a miss.',
  },
  shooting: {
    title: 'Shooting',
    body: 'A reticle sweeps across the goal mouth. The keeper is standing to one side — tap when the reticle is on the far side, away from them. That\'s your target zone.',
  },
  passing: {
    title: 'Passing',
    body: 'The reticle sweeps toward your teammate. Tap when it\'s in the gold zone to thread the pass through cleanly — miss the window and it\'s cut out or overhit.',
  },
  tackle: {
    title: 'Tackling',
    body: 'Time your tap to win the ball cleanly. Go in too early or too late and you risk a foul instead of a clean challenge — tight timing is both safer and better here.',
  },
  dribble: {
    title: 'Dribbling',
    body: 'Beat your marker by tapping in the right window as the reticle sweeps. This one rewards precision over pure speed — rushing it usually costs you the ball.',
  },
  'cross-header': {
    title: 'Crossing & Heading',
    body: 'Time your jump to meet the cross. Tap when the reticle lines up with the gold zone for the cleanest possible contact on the ball.',
  },
  keeper: {
    title: 'Goalkeeping',
    body: 'React to the shot as it comes in. Tap when the reticle hits the gold zone to get a hand to it — reflexes matter more than anything else in goal.',
  },
  rondo: {
    title: 'Rondo',
    body: 'Keep the ball under pressure. Tap the right option as it\'s highlighted to keep possession moving before the press closes you down.',
  },
  targets: {
    title: 'Targets',
    body: 'Hit each target as it appears. Both your timing and your accuracy count toward the grade you get out of the drill.',
  },
  sprint: {
    title: 'Sprint Drill',
    body: 'Tap in rhythm as the prompts appear. Consistency matters as much as raw speed — a broken rhythm costs more than a slightly slower one.',
  },
  street: {
    title: 'Street Football',
    body: 'Quick reflexes and instinct decide this one. Tap in time with what\'s happening on screen — there\'s no time to overthink it out here.',
  },
}

const STORAGE_KEY = 'kickoff-star:tutorials-seen'

function readSeen(): Set<TutorialKey> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return new Set()
    return new Set(JSON.parse(raw))
  } catch {
    return new Set()
  }
}

function writeSeen(seen: Set<TutorialKey>): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...seen]))
  } catch {
    // localStorage unavailable (private browsing, etc) — tutorials will
    // just show every time in that case, which is a safe fallback, not a crash.
  }
}

/** Has this specific tutorial already been dismissed, ever, on this device? */
export function hasSeenTutorial(key: TutorialKey): boolean {
  return readSeen().has(key)
}

function markTutorialSeen(key: TutorialKey): void {
  const seen = readSeen()
  seen.add(key)
  writeSeen(seen)
}

/** React hook wrapping the above — tracks dismissal in component state too, so the gate re-renders immediately on dismiss. */
export function useTutorialGate(key: TutorialKey): { shouldShow: boolean; dismiss: () => void } {
  const [dismissedThisSession, setDismissedThisSession] = useState(false)
  const shouldShow = !dismissedThisSession && !hasSeenTutorial(key)
  const dismiss = () => {
    markTutorialSeen(key)
    setDismissedThisSession(true)
  }
  return { shouldShow, dismiss }
}
