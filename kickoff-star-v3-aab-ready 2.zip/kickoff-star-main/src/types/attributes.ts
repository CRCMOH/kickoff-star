// P81 — Joel: "lessen the attributes a bit because currently managing all
// of them can be confusing." Reduced from 12 to 10 by merging genuine
// near-duplicates rather than cutting distinct skills: agility (explosive
// change of direction) folds into pace (both physical quickness), and
// concentration (staying switched on) folds into positioning (both
// awareness/game-sense). The four technical attributes stay untouched —
// passing, shooting, dribbling, and tackling are the most clearly distinct
// actions on the pitch and cutting any of them would lose real signal, not
// just reduce clutter. Old saves migrate their retired attribute values
// into the merged one on load — see migrateAttributes() in engine/save.ts.
export type TechnicalAttribute = 'passing' | 'shooting' | 'dribbling' | 'tackling'
export type PhysicalAttribute = 'pace' | 'strength' | 'stamina'
export type MentalAttribute = 'vision' | 'composure' | 'positioning'

export type OutfieldAttribute = TechnicalAttribute | PhysicalAttribute | MentalAttribute

export type GoalkeeperAttribute = 'reflexes' | 'handling' | 'gkPositioning' | 'distribution'

export const OUTFIELD_ATTRIBUTES: OutfieldAttribute[] = [
  'passing', 'shooting', 'dribbling', 'tackling',
  'pace', 'strength', 'stamina',
  'vision', 'composure', 'positioning',
]

export const GOALKEEPER_ATTRIBUTES: GoalkeeperAttribute[] = [
  'reflexes', 'handling', 'gkPositioning', 'distribution',
]

// 1-20 scale per spec. Current Ability is visible-ish via derived grades,
// never shown as a raw number to the player (per locked "hide the CA" rule).
export type AttributeValue = number // 1-20

export interface OutfieldAttributes {
  kind: 'outfield'
  values: Record<OutfieldAttribute, AttributeValue>
}

export interface GoalkeeperAttributes {
  kind: 'goalkeeper'
  values: Record<GoalkeeperAttribute, AttributeValue>
}

export type PlayerAttributes = OutfieldAttributes | GoalkeeperAttributes

export type Position =
  | 'GK'
  | 'CB' | 'FB'
  | 'CM' | 'WM'
  | 'WG' | 'ST'

export function isGoalkeeperPosition(position: Position): boolean {
  return position === 'GK'
}
