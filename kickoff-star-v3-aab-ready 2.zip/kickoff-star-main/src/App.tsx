import { useState } from 'react'
import SplashScreen from './screens/SplashScreen'
import MainMenu from './screens/MainMenu'
import PlayerCreation from './screens/PlayerCreation'
import StoryIntro from './screens/StoryIntro'
import SchoolSelection from './screens/SchoolSelection'
import TrialsScreen from './screens/TrialsScreen'
import Career from './screens/Career'
import SettingsScreen from './screens/SettingsScreen'
import CreditsScreen from './screens/CreditsScreen'
import HelpScreen from './screens/HelpScreen'
import SaveSlotsScreen from './screens/SaveSlotsScreen'
import { useCareerStore } from './store/careerStore'
import { listSaves, type SaveSlotId } from './engine/save'
import type { School } from './engine/schools'
import type { SquadRole } from './engine/trials'

type Screen = 'splash' | 'menu' | 'create' | 'story' | 'school' | 'trials' | 'career' | 'settings' | 'credits' | 'slots' | 'help'

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash')
  const [chosenSchool, setChosenSchool] = useState<School | null>(null)
  const [targetSlot, setTargetSlot] = useState<SaveSlotId>(0)
  const player = useCareerStore((s) => s.player)
  const loadFromSlot = useCareerStore((s) => s.loadFromSlot)
  const setSchool = useCareerStore((s) => s.setSchool)
  const completeTrials = useCareerStore((s) => s.completeTrials)

  const resumeFromLoadedPlayer = () => {
    const p = useCareerStore.getState().player
    if (p && p.trialWeekCompleted < 3) {
      // Trials are a single-sitting arc; if it was left incomplete, restart cleanly
      // from school selection rather than resuming a half-finished, unsaved trial state.
      setChosenSchool(null)
      setScreen('school')
    } else {
      setScreen('career')
    }
  }

  // P80 — Joel: "make sure players can have different save states." Real bug:
  // this used to be `loadFromSlot(0)` hardcoded, and "Continue"/"Load Career"
  // were two buttons that did the literal same thing. Now "Continue" quick-
  // resumes whichever of the 3 slots was played most recently (the natural
  // "pick up where I left off" behavior), while "Load Career" opens the
  // full slot picker for anyone actually managing multiple careers.
  const handleQuickContinue = async () => {
    const saves = await listSaves()
    let mostRecent: SaveSlotId | null = null
    let mostRecentAt = ''
    saves.forEach((s, i) => {
      if (s && s.savedAt > mostRecentAt) { mostRecentAt = s.savedAt; mostRecent = i as SaveSlotId }
    })
    if (mostRecent === null) return
    await loadFromSlot(mostRecent)
    resumeFromLoadedPlayer()
  }

  const handlePlaySlot = async (slot: SaveSlotId) => {
    await loadFromSlot(slot)
    resumeFromLoadedPlayer()
  }

  // "New Career" from the main menu: a completely fresh install (no saves
  // at all) goes straight into creation for the smoothest possible first
  // run. Once any save exists, route through the slot picker instead —
  // silently overwriting slot 0 with no warning, which is what used to
  // happen, is exactly the bug being fixed here.
  const handleNewCareerFromMenu = async () => {
    const saves = await listSaves()
    if (saves.every((s) => !s)) {
      setTargetSlot(0)
      setScreen('create')
      return
    }
    setScreen('slots')
  }

  const handleSchoolChosen = (school: School) => {
    setChosenSchool(school)
    setSchool(school.id)
    setScreen('trials')
  }

  const handleTrialsComplete = (role: SquadRole, performance: number) => {
    if (role === 'released') {
      // didn't make the cut — try a different school rather than dead-ending
      setChosenSchool(null)
      setScreen('school')
      return
    }
    completeTrials(role, performance)
    setScreen('career')
  }

  if (screen === 'splash') return <SplashScreen onDone={() => setScreen('menu')} />
  if (screen === 'menu') {
    return (
      <MainMenu
        onNewCareer={handleNewCareerFromMenu}
        onContinue={handleQuickContinue}
        onLoadCareer={() => setScreen('slots')}
        onOpenSettings={() => setScreen('settings')}
        onOpenCredits={() => setScreen('credits')}
        onOpenHelp={() => setScreen('help')}
      />
    )
  }
  if (screen === 'settings') {
    return <SettingsScreen onBack={() => setScreen('menu')} />
  }
  if (screen === 'credits') {
    return <CreditsScreen onBack={() => setScreen('menu')} />
  }
  if (screen === 'help') {
    return <HelpScreen onBack={() => setScreen('menu')} />
  }
  if (screen === 'slots') {
    return (
      <SaveSlotsScreen
        onBack={() => setScreen('menu')}
        onPlaySlot={handlePlaySlot}
        onNewCareerInSlot={(slot) => { setTargetSlot(slot); setScreen('create') }}
      />
    )
  }
  if (screen === 'create') {
    return <PlayerCreation onComplete={() => setScreen('story')} onBack={() => setScreen('menu')} targetSlot={targetSlot} />
  }
  if (screen === 'story') {
    return <StoryIntro onComplete={() => setScreen('school')} />
  }
  if (screen === 'school') {
    return <SchoolSelection onChoose={handleSchoolChosen} />
  }
  if (screen === 'trials' && player && chosenSchool) {
    return <TrialsScreen player={player} school={chosenSchool} onComplete={handleTrialsComplete} />
  }
  return <Career onExitToMenu={() => setScreen('menu')} />
}
