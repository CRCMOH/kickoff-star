import { useEffect, useState } from 'react'
import { matchXpBreakdown, type MatchXpStats, type CompetitionTier } from '../engine/xp'
import { haptics } from '../engine/haptics'
import AnimatedNumber from './AnimatedNumber'

// P82 — Joel: "before the exp thingy pops up there should be a screen that
// shows the player how they got that exp... it should also look cool. And
// different for goalkeeper." Before this, matchXp arrived at the allocation
// screen as a single opaque number — no way to see that a goal was worth
// 50, a division-1 fixture worth 60, a 9.2 rating worth 820. This reveals
// the real formula, itemized, in the same order it was actually earned
// (matchXpBreakdown is the exact function matchXpEarned derives its total
// from — never two competing numbers that could quietly disagree). No
// hardcoded GK/outfield branching needed: whichever categories are
// genuinely nonzero for THIS match are the ones that show, so a keeper
// naturally sees "Saves" where a striker sees "Goals" — same component,
// different result, purely from what actually happened on the pitch.

interface XpBreakdownScreenProps {
  tier: CompetitionTier
  rating: number
  goals: number
  assists: number
  matchStats?: MatchXpStats
  divisionTier?: 1 | 2 | 3
  total: number
  onDone: () => void
}

export default function XpBreakdownScreen({ tier, rating, goals, assists, matchStats, divisionTier, total, onDone }: XpBreakdownScreenProps) {
  const items = matchXpBreakdown(tier, rating, goals, assists, matchStats, divisionTier)
  const [revealedCount, setRevealedCount] = useState(0)
  const [showTotal, setShowTotal] = useState(false)

  useEffect(() => {
    if (revealedCount >= items.length) {
      const t = window.setTimeout(() => setShowTotal(true), 250)
      return () => window.clearTimeout(t)
    }
    haptics.tap()
    const t = window.setTimeout(() => setRevealedCount((c) => c + 1), 260)
    return () => window.clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [revealedCount])

  useEffect(() => {
    if (showTotal) haptics.success()
  }, [showTotal])

  const runningTotal = items.slice(0, revealedCount).reduce((s, i) => s + i.xp, 0)

  return (
    <div className="fixed inset-0 z-[65] bg-ks-black flex flex-col items-center justify-center px-6 overflow-hidden">
      {/* faint radial glow behind everything, same family as the goal celebration's treatment but calm rather than explosive */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at 50% 40%, rgba(212,175,55,0.10), transparent 65%)' }}
      />

      <div className="relative z-10 w-full max-w-sm flex flex-col gap-1">
        <span className="font-display tracking-[0.25em] text-[10px] text-ks-gold uppercase text-center mb-1">
          experience earned
        </span>

        <div className="rounded-xl border border-ks-border bg-[#0f0f0d] overflow-hidden texture-turf relative">
          <div className="flex flex-col relative z-10">
            {items.map((item, i) => (
              <div
                key={item.label}
                className={`flex items-center justify-between px-4 py-2.5 ${i !== 0 ? 'border-t border-ks-border/40' : ''}`}
                style={{
                  opacity: i < revealedCount ? 1 : 0,
                  transform: i < revealedCount ? 'translateY(0)' : 'translateY(6px)',
                  transition: 'opacity 0.3s ease-out, transform 0.3s ease-out',
                }}
              >
                <span className="flex flex-col">
                  <span className="text-ks-ink text-sm font-display tracking-wide">{item.label}</span>
                  <span className="text-[10px] text-ks-muted">{item.detail}</span>
                </span>
                <span className="text-ks-gold font-display text-base tabular-nums">+{item.xp}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between px-2 pt-4">
          <span className="font-display tracking-[0.2em] text-[11px] text-ks-muted uppercase">total xp</span>
          <span className="font-display text-4xl text-ks-gold tabular-nums" style={{ textShadow: showTotal ? '0 0 24px rgba(212,175,55,0.5)' : undefined }}>
            <AnimatedNumber from={0} to={showTotal ? total : runningTotal} duration={showTotal ? 500 : 200} />
          </span>
        </div>

        {showTotal && (
          <button
            onClick={onDone}
            className="mt-6 w-full rounded-xl bg-ks-gold text-ks-black font-display tracking-widest text-sm uppercase py-3.5"
            style={{ animation: 'staggerIn 0.3s ease-out' }}
          >
            Spend it →
          </button>
        )}
      </div>
    </div>
  )
}
