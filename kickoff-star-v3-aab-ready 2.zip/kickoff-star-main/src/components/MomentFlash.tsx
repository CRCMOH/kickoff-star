import { useEffect, useState } from 'react'
import { haptics } from '../engine/haptics'
import { sfx } from '../engine/audio'

// P79 — Joel: "upgrade the animations for everything." Goals got the full
// confetti/shake/ray treatment in P77; red cards and serious injuries stayed
// completely flat — a feed line and nothing else, despite being two of the
// biggest, most match-changing moments there are. This is the same visual
// language as GoalCelebration (screen shake, expanding ring, big cropped
// type) but shorter and starker — no confetti, no light rays, a colder
// palette — so it reads as genuinely bad news, not a smaller version of a
// celebration.

export type MomentFlashKind = 'red-card' | 'injury' | 'big-save' | 'crunching-tackle'

interface MomentFlashProps {
  kind: MomentFlashKind
  detail?: string
  minute: number
  onDone: () => void
}

const DURATION_MS = 1700

const KIND_LABEL: Record<MomentFlashKind, string> = {
  'red-card': 'RED CARD',
  injury: 'INJURY',
  'big-save': 'WHAT A SAVE!',
  'crunching-tackle': 'CRUNCHING TACKLE!',
}

const KIND_ACCENT: Record<MomentFlashKind, string> = {
  'red-card': '#e0483e',
  injury: '#e08a3e',
  'big-save': '#3fb8af',
  'crunching-tackle': '#d4af37',
}

const KIND_IS_GOOD: Record<MomentFlashKind, boolean> = {
  'red-card': false,
  injury: false,
  'big-save': true,
  'crunching-tackle': true,
}

export default function MomentFlash({ kind, detail, minute, onDone }: MomentFlashProps) {
  const [phase, setPhase] = useState<'flash' | 'hold' | 'out'>('flash')
  const accent = KIND_ACCENT[kind]
  const isGood = KIND_IS_GOOD[kind]

  useEffect(() => {
    if (isGood) {
      haptics.success()
      sfx.bigMoment()
    } else {
      haptics.fail()
      if (kind === 'red-card') sfx.card()
      else sfx.injury()
    }
    const t1 = window.setTimeout(() => setPhase('hold'), 100)
    const t2 = window.setTimeout(() => setPhase('out'), DURATION_MS - 220)
    const t3 = window.setTimeout(onDone, DURATION_MS)
    return () => { window.clearTimeout(t1); window.clearTimeout(t2); window.clearTimeout(t3) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div
      className="fixed inset-0 z-[70] flex flex-col items-center justify-center transition-opacity duration-200 overflow-hidden"
      style={{
        background: `radial-gradient(ellipse at center, ${accent}${isGood ? '18' : '22'}, rgba(0,0,0,0.95) 70%)`,
        opacity: phase === 'out' ? 0 : 1,
        animation: phase === 'flash' && !isGood ? 'screenShake 0.4s ease-out' : undefined,
      }}
    >
      {phase === 'flash' && (
        <div className="fixed inset-0" style={{ background: accent, animation: 'goalflash 0.3s ease-out forwards', opacity: isGood ? 0.35 : 0.5 }} />
      )}

      {phase !== 'flash' && (
        <div
          className="fixed rounded-full pointer-events-none"
          style={{ width: 160, height: 160, border: `3px solid ${accent}`, animation: 'ringExpand 0.8s cubic-bezier(0.2,0.8,0.3,1) forwards' }}
        />
      )}

      <div
        className="w-full flex flex-col items-center gap-2 relative z-10"
        style={{
          transform: phase === 'flash' ? 'scale(0.75)' : 'scale(1)',
          opacity: phase === 'flash' ? 0 : 1,
          transition: 'transform 0.3s cubic-bezier(0.34,1.2,0.64,1), opacity 0.2s ease-out',
        }}
      >
        <div
          className="font-display font-black tracking-[0.1em] uppercase leading-none w-full text-center px-2 text-6xl"
          style={{ color: accent, textShadow: `0 0 30px ${accent}77` }}
        >
          {KIND_LABEL[kind]}
        </div>
        {detail && <div className="text-ks-ink text-base font-display tracking-wide text-center px-6">{detail}</div>}
        <div className="text-ks-muted text-[11px] uppercase tracking-[0.2em]">{minute}'</div>
      </div>
    </div>
  )
}
