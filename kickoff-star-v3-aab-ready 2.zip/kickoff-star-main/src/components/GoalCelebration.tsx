import { useEffect, useMemo, useState } from 'react'
import Avatar from './Avatar'
import { haptics } from '../engine/haptics'

// P47 — Joel: "when someone scores it's almost impossible to tell they did."
// A goal was rendering as a slightly-bigger feed line and a 0.4s number pop —
// the single biggest scoring moment in football, given the same visual
// weight as a throw-in. That first fix was a real full-screen takeover.
//
// P77 — Joel: "make it more fun and stunning." The flash/scale/hold sequence
// from P47 was solid but static — one flash, one scale-in, done. This adds
// the things a real broadcast goal replay has: a confetti burst for YOUR
// goal specifically (not a concession, not a generic team goal), a real
// screen shake on impact, rotating light-ray sweeps behind the type, and a
// scoreboard that flips into place like a stadium screen rather than fading.
// All pure CSS — no new libraries or asset weight for a 2-second moment.

export type CelebrationKind = 'player-goal' | 'player-assist' | 'team-goal' | 'concede'

interface CelebrationProps {
  kind: CelebrationKind
  scorerName?: string
  homeShort: string
  awayShort: string
  homeScore: number
  awayScore: number
  minute: number
  avatarId?: number
  onDone: () => void
}

const DURATION_MS = 2400

const KIND_LABEL: Record<CelebrationKind, string> = {
  'player-goal': 'GOAL!',
  'player-assist': 'ASSIST!',
  'team-goal': 'GOAL',
  concede: 'CONCEDED',
}

const CONFETTI_COLORS = ['#d4af37', '#f4e5a1', '#ffffff', '#3fb8af']

interface ConfettiPiece {
  id: number
  left: number
  delay: number
  duration: number
  color: string
  cx: number
  cy: number
  cr: number
  size: number
  round: boolean
}

function makeConfetti(count: number): ConfettiPiece[] {
  return Array.from({ length: count }, (_, i) => {
    const angle = (Math.PI * 2 * i) / count + Math.random() * 0.6
    const distance = 90 + Math.random() * 140
    return {
      id: i,
      left: 50 + (Math.random() - 0.5) * 30,
      delay: Math.random() * 120,
      duration: 900 + Math.random() * 500,
      color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      cx: Math.cos(angle) * distance,
      cy: Math.sin(angle) * distance - 60, // biased upward, gravity-ish arc via the negative offset
      cr: (Math.random() - 0.5) * 720,
      size: 5 + Math.random() * 5,
      round: i % 2 === 0,
    }
  })
}

export default function GoalCelebration({ kind, scorerName, homeShort, awayShort, homeScore, awayScore, minute, avatarId, onDone }: CelebrationProps) {
  const [phase, setPhase] = useState<'flash' | 'hold' | 'out'>('flash')
  const isPlayerGoal = kind === 'player-goal'
  const confetti = useMemo(() => (isPlayerGoal ? makeConfetti(28) : []), [isPlayerGoal])

  useEffect(() => {
    if (kind === 'concede') haptics.fail()
    else haptics.goal()
    const t1 = window.setTimeout(() => setPhase('hold'), 120)
    const t2 = window.setTimeout(() => setPhase('out'), DURATION_MS - 260)
    const t3 = window.setTimeout(onDone, DURATION_MS)
    return () => { window.clearTimeout(t1); window.clearTimeout(t2); window.clearTimeout(t3) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const isGood = kind !== 'concede'
  const accent = isGood ? '#d4af37' : '#e0483e'

  return (
    <div
      className="fixed inset-0 z-[70] flex flex-col items-center justify-center transition-opacity duration-200 overflow-hidden"
      style={{
        background: isGood
          ? 'radial-gradient(ellipse at center, rgba(212,175,55,0.22), rgba(0,0,0,0.94) 70%)'
          : 'radial-gradient(ellipse at center, rgba(224,72,62,0.16), rgba(0,0,0,0.94) 70%)',
        opacity: phase === 'out' ? 0 : 1,
        animation: phase === 'flash' && isGood ? 'screenShake 0.5s ease-out' : undefined,
      }}
    >
      {/* flash frame — a single bright pulse right on impact */}
      {phase === 'flash' && (
        <div className="fixed inset-0 bg-white" style={{ animation: 'goalflash 0.35s ease-out forwards' }} />
      )}

      {/* rotating light-ray sweep — reads as a floodlight catching the moment, not decoration for its own sake */}
      {isGood && phase !== 'flash' && (
        <div
          className="fixed pointer-events-none"
          style={{
            top: '50%', left: '50%', width: '200vmax', height: '200vmax',
            marginLeft: '-100vmax', marginTop: '-100vmax',
            background: `conic-gradient(from 0deg, transparent 0deg, ${accent}33 8deg, transparent 16deg, transparent 100deg, ${accent}22 108deg, transparent 116deg, transparent 200deg, ${accent}33 208deg, transparent 216deg, transparent 360deg)`,
            animation: 'rayRotate 2.2s ease-out forwards',
          }}
        />
      )}

      {/* expanding impact ring right behind the type */}
      {phase !== 'flash' && (
        <div
          className="fixed rounded-full pointer-events-none"
          style={{
            width: 180, height: 180, border: `3px solid ${accent}`,
            animation: 'ringExpand 0.9s cubic-bezier(0.2, 0.8, 0.3, 1) forwards',
          }}
        />
      )}

      {/* confetti — only for your own goal, the moment that deserves it most */}
      {isPlayerGoal && phase !== 'flash' && confetti.map((c) => (
        <div
          key={c.id}
          className="fixed pointer-events-none"
          style={{
            left: `${c.left}%`, top: '42%',
            width: c.round ? c.size : c.size * 0.6, height: c.size,
            backgroundColor: c.color,
            borderRadius: c.round ? '50%' : '1px',
            ['--cx' as string]: `${c.cx}px`,
            ['--cy' as string]: `${c.cy}px`,
            ['--cr' as string]: `${c.cr}deg`,
            animation: `confettiBurst ${c.duration}ms cubic-bezier(0.15,0.6,0.4,1) ${c.delay}ms forwards`,
          }}
        />
      ))}

      <div
        className="w-full flex flex-col items-center gap-3 relative z-10"
        style={{
          transform: phase === 'flash' ? 'scale(0.7)' : 'scale(1)',
          opacity: phase === 'flash' ? 0 : 1,
          transition: 'transform 0.35s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.25s ease-out',
        }}
      >
        {avatarId !== undefined && isGood && (
          <Avatar id={avatarId} size={72} className="mb-1" style={{ boxShadow: `0 0 30px ${accent}66` }} />
        )}

        {/* P58 — reference video: the GOAL label runs edge-to-edge, letters
            deliberately cropped at the sides on your own goal — the biggest
            moment gets the most visceral typography, not a neatly
            contained label like everything else on screen. */}
        <div
          className={`font-display font-black tracking-[0.1em] uppercase leading-none w-full text-center px-2 ${kind === 'player-goal' ? 'text-8xl' : 'text-6xl'}`}
          style={{ color: accent, textShadow: `0 0 40px ${accent}88`, whiteSpace: 'nowrap' }}
        >
          {KIND_LABEL[kind]}
        </div>

        {scorerName && (
          <div className="text-ks-ink text-lg font-display tracking-wide">{scorerName}</div>
        )}
        <div className="text-ks-muted text-[11px] uppercase tracking-[0.2em]">{minute}'</div>

        {/* scoreboard flips into place like a real stadium screen rather than fading in flat */}
        <div
          className="flex items-center gap-4 mt-2 border-t border-white/10 pt-4"
          style={{
            animation: phase !== 'flash' ? 'scoreboardFlip 0.55s cubic-bezier(0.2,0.7,0.3,1) 0.15s backwards' : undefined,
            transformStyle: 'preserve-3d',
            perspective: 400,
          }}
        >
          <span className="font-display text-ks-ink text-base tracking-wide">{homeShort}</span>
          <span className="font-display text-3xl tracking-widest" style={{ color: accent }}>{homeScore}–{awayScore}</span>
          <span className="font-display text-ks-ink text-base tracking-wide">{awayShort}</span>
        </div>
      </div>
    </div>
  )
}
