import type { ScorerEntry } from '../engine/league'

// P71 — Joel: "player's goals should also be synced to the top goalscorer
// thingy so his name also appears." Renders engine/league.ts's
// divisionScorers() output — the same list of NPC notable players as
// before, but with the player's own live season goals merged in and
// highlighted, ranked exactly where his tally puts him.
export default function ScorersTable({ scorers }: { scorers: ScorerEntry[] }) {
  if (scorers.length === 0) {
    return (
      <div className="rounded-xl border border-ks-border bg-[#0f0f0d] px-4 py-6 text-center text-[11px] text-ks-muted">
        No goals scored in this division yet this season.
      </div>
    )
  }

  return (
    <div className="rounded-xl border border-ks-border bg-[#0f0f0d] overflow-hidden">
      {scorers.slice(0, 15).map((s, i) => (
        <div
          key={`${s.name}-${s.club}-${i}`}
          className={`flex items-center gap-3 px-3 py-2.5 ${i !== 0 ? 'border-t border-ks-border/40' : ''} ${
            s.isPlayer ? 'bg-ks-gold/10' : ''
          }`}
        >
          <span className={`w-5 text-[11px] font-display text-right ${s.isPlayer ? 'text-ks-gold' : 'text-ks-muted'}`}>
            {i + 1}
          </span>
          <span className="flex flex-col flex-1 min-w-0">
            <span className={`text-sm font-display tracking-wide truncate ${s.isPlayer ? 'text-ks-gold' : 'text-ks-ink'}`}>
              {s.name}
              {s.isPlayer && <span className="ml-1.5 text-[9px] tracking-widest uppercase text-ks-accent opacity-90">you</span>}
            </span>
            <span className="text-[10px] text-ks-muted truncate">{s.club}</span>
          </span>
          <span className={`text-base font-display tabular-nums ${s.isPlayer ? 'text-ks-gold' : 'text-ks-ink'}`}>
            {s.goals}
          </span>
        </div>
      ))}
    </div>
  )
}
