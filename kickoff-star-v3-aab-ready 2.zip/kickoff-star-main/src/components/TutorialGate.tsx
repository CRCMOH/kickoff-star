import { useTutorialGate, TUTORIALS, type TutorialKey } from '../engine/tutorials'

// P83 — wraps a minigame so its FIRST-EVER play shows a short explanation
// before the minigame actually mounts, rather than a hint layered on top
// of an already-running timer. Because the tutorial card fully replaces
// the minigame (not an overlay on top of it), the minigame's own internal
// timers/animations don't start ticking until the player has actually
// dismissed the explanation — no wasted reps burned while reading.
export default function TutorialGate({ tutorialKey, children }: { tutorialKey: TutorialKey; children: React.ReactNode }) {
  const { shouldShow, dismiss } = useTutorialGate(tutorialKey)
  const content = TUTORIALS[tutorialKey]

  if (!shouldShow) return <>{children}</>

  return (
    <div className="rounded-xl border border-ks-gold/40 bg-[#0f0f0d] px-5 py-6 flex flex-col items-center gap-4 text-center">
      <span className="font-display tracking-[0.2em] text-[10px] text-ks-gold uppercase">first time — {content.title}</span>
      <p className="text-ks-ink text-sm leading-relaxed">{content.body}</p>
      <button
        onClick={dismiss}
        className="w-full rounded-lg bg-ks-gold text-ks-black font-display tracking-widest text-xs uppercase py-3"
      >
        Got it — let's go
      </button>
    </div>
  )
}
