import { useState } from 'react'
import { isMuted, setMuted } from '../engine/audio'
import { syncMusicMute } from '../engine/music'

// Settings — reachable from the main menu. The "Settings" button existed on
// the menu since before this screen did (see MENU_ITEMS in MainMenu.tsx) but
// had no handler at all, so tapping it did nothing. This is that missing
// screen: currently just audio, but built as a list so more toggles (e.g.
// haptics, notifications) can drop in beside it later without restructuring.

export default function SettingsScreen({ onBack }: { onBack: () => void }) {
  const [muted, setMutedState] = useState(isMuted())

  const toggleAudio = () => {
    const next = !muted
    setMuted(next)
    syncMusicMute()
    setMutedState(next)
  }

  return (
    <div className="min-h-screen w-full bg-ks-black flex flex-col">
      <div className="sticky top-0 z-20 bg-ks-black/95 backdrop-blur border-b border-ks-border/50">
        <div className="max-w-md mx-auto w-full px-4 py-3 flex items-center gap-3">
          <button
            onClick={onBack}
            className="text-ks-muted hover:text-ks-gold transition-colors text-lg leading-none"
            aria-label="Back"
          >
            ←
          </button>
          <span className="font-display tracking-widest text-[11px] text-ks-gold uppercase">Settings</span>
        </div>
      </div>

      <div className="flex-1 max-w-md mx-auto w-full px-4 py-6 flex flex-col gap-2.5">
        <div className="text-[10px] tracking-[0.2em] text-ks-muted uppercase px-1 mb-1">audio</div>

        <button
          onClick={toggleAudio}
          className="w-full rounded-xl border border-ks-border bg-[#0f0f0d] px-4 py-3.5 flex items-center justify-between hover:border-ks-gold/40 transition-colors"
        >
          <span className="flex flex-col text-left">
            <span className="font-display tracking-wide text-ks-ink text-sm">Sound & music</span>
            <span className="text-[11px] text-ks-muted mt-0.5">
              {muted ? 'Muted — sfx and music are off' : 'On — crowd sfx and background music play'}
            </span>
          </span>
          <span
            className={`relative w-11 h-6 rounded-full transition-colors shrink-0 ${muted ? 'bg-ks-border' : 'bg-ks-gold'}`}
          >
            <span
              className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-ks-black transition-transform ${muted ? '' : 'translate-x-5'}`}
            />
          </span>
        </button>

        <p className="text-[10px] text-ks-muted leading-relaxed px-1 mt-1">
          This mutes everything at once — kickoff whistles, goal celebrations, timing-bar feedback and the background track. Your choice is saved on this device.
        </p>
      </div>
    </div>
  )
}
