// P80 — Joel: "fix the credits thingy." Real bug, same class as the old
// dead Settings button: "Credits" has sat on the main menu with an action
// of 'credits' and NO handler anywhere in the app — tapping it did nothing
// at all. This is that missing screen.

export default function CreditsScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen w-full bg-ks-black flex flex-col">
      <div className="sticky top-0 z-20 bg-ks-black/95 backdrop-blur border-b border-ks-border/50">
        <div className="max-w-md mx-auto w-full px-4 py-3 flex items-center gap-3">
          <button
            onClick={onBack}
            className="text-ks-muted hover:text-ks-gold transition-colors text-lg leading-none"
            aria-label="Back"
          >
            ←
          </button>
          <span className="font-display tracking-widest text-[11px] text-ks-gold uppercase">Credits</span>
        </div>
      </div>

      <div className="flex-1 max-w-md mx-auto w-full px-4 py-10 flex flex-col items-center gap-8 text-center">
        <div className="flex flex-col items-center gap-2">
          <span className="font-display text-3xl tracking-wide text-ks-gold">KICKOFF STAR</span>
          <span className="text-[11px] text-ks-muted uppercase tracking-[0.2em]">from school football to a pro contract</span>
        </div>

        <div className="w-full flex flex-col items-center gap-1.5 border-y border-ks-border/50 py-6">
          <span className="text-[10px] text-ks-muted uppercase tracking-[0.2em]">created by</span>
          <span className="font-display text-2xl text-ks-ink tracking-wide">Joel Kazadi</span>
        </div>

        <p className="text-[12px] text-ks-muted leading-relaxed px-2">
          Thanks for playing. Every division, every drill, every headline in the Gazette was built to make one career feel like your own.
        </p>

        <div className="w-full flex flex-col items-center gap-1 border-t border-ks-border/50 pt-5">
          <span className="text-[10px] text-ks-muted uppercase tracking-[0.2em]">music</span>
          <span className="text-[11px] text-ks-ink/80">Pulse of the Pitch</span>
          <span className="text-[11px] text-ks-ink/80">From Pavement to Green</span>
        </div>

        <span className="text-[10px] text-ks-muted/60 uppercase tracking-[0.2em] mt-auto pt-6">v3.0.0</span>
      </div>
    </div>
  )
}
