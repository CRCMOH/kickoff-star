import { Section } from '../components/ui'

// P83 — Joel: "add a help section to the menu page that basically explains
// each and everything a player probably needs to know." A comprehensive
// reference, organized by topic rather than one long wall of text, so a
// player can jump straight to whatever's actually confusing them right now
// instead of reading the whole thing to find one answer.

export default function HelpScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen w-full bg-ks-black flex flex-col">
      <div className="sticky top-0 z-20 bg-ks-black/95 backdrop-blur border-b border-ks-border/50">
        <div className="max-w-md mx-auto w-full px-4 py-3 flex items-center gap-3">
          <button onClick={onBack} className="text-ks-muted hover:text-ks-gold transition-colors text-lg leading-none" aria-label="Back">←</button>
          <span className="font-display tracking-widest text-[11px] text-ks-gold uppercase">Help</span>
        </div>
      </div>

      <div className="flex-1 max-w-md mx-auto w-full px-4 py-6 flex flex-col gap-2.5">
        <Section title="the basics" defaultOpen>
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            You're playing one career, start to finish: grassroots football as a teenager, through to a professional contract if you make it. Every week you'll train, play matches, and make decisions — school, relationships, money — that shape who your player becomes. There's no reloading a bad week; the story keeps moving forward, same as a real career would.
          </p>
        </Section>

        <Section title="attributes & growth">
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            Your player has attributes across three groups — technical (passing, shooting, dribbling, tackling), physical (pace, strength, stamina), and mental (vision, composure, positioning) — or four goalkeeping attributes if you play in goal. These combine, weighted by your position, into your overall rating.
          </p>
          <p className="text-[12px] text-ks-ink/90 leading-relaxed mt-2">
            You grow by spending XP earned from training and matches. Two things cap how far you can go: your hidden potential (every player has one, and it's never fully revealed — you'll get a sense of it over time) and a hard ceiling on overall rating for whatever stage of your career you're in. Grassroots players can't exceed a 60 overall, academy players can't exceed 73 — you can only break past those ceilings by earning your way into the next stage.
          </p>
        </Section>

        <Section title="matches">
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            You don't control every kick — you make the decisions that matter. When a real moment falls to you (a shot, a tackle, a big pass), you'll play a short mini-game to execute it: time your tap to the gold zone. The first time you see each kind of mini-game, a quick explainer shows you exactly what to do.
          </p>
          <p className="text-[12px] text-ks-ink/90 leading-relaxed mt-2">
            Your energy matters — drop below 50 and you'll start matches on the bench instead of in the starting XI, coming on only later in the game. Bigger matches (cup ties, internationals) and higher divisions are worth more XP than a routine league game.
          </p>
        </Section>

        <Section title="training">
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            Training sessions target specific attributes through drills and mini-games. How well you perform each drill decides how much XP you earn — a perfect execution earns meaningfully more than scraping by. That XP is yours to spend on whichever attributes you want once the session ends, not locked to what you just trained.
          </p>
        </Section>

        <Section title="energy & injuries">
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            Matches and training cost energy; rest days and recovery items bring it back. Playing on low energy raises your injury risk and hurts your performance — sometimes the right move is to sit a week out rather than push through.
          </p>
        </Section>

        <Section title="transfers & divisions">
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            Play well for long enough — strong ratings, a growing reputation — and clubs from a higher division will come calling. Accepting an offer moves you to that club and division. It happens one step at a time: a Division 3 side won't get a call from the top flight overnight, but a season of good form can start that climb.
          </p>
        </Section>

        <Section title="relationships & school">
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            The people around you — family, coaches, teammates, friends — aren't just flavor. A strong relationship with a parent can mean a better allowance; your coach's trust in you affects your role in the squad. These build and fade based on the choices you actually make, week to week.
          </p>
        </Section>

        <Section title="the shop">
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            Boots, kit, and recovery items give temporary attribute boosts or restore energy. Equipment boosts wear off after a set number of weeks — check how long before you spend on something that won't last past your next big match.
          </p>
        </Section>

        <Section title="save slots">
          <p className="text-[12px] text-ks-ink/90 leading-relaxed">
            You have 3 independent save slots — run multiple careers side by side if you want to try a different position or archetype without losing progress on another. "Continue" from the main menu always picks up whichever slot you played most recently; "Load Career" lets you choose between all three directly.
          </p>
        </Section>
      </div>
    </div>
  )
}
