import { useEffect, useState } from 'react'
import { listSaves, deleteSave, type SaveGame, type SaveSlotId } from '../engine/save'
import { computeCurrentAbility, toOvr } from '../engine/rating'

// P80 — Joel: "make sure players can have different save states." Real bug
// found: the engine layer (engine/save.ts) already fully supported 3
// independent save slots — versioned, migratable, the works — but NOTHING
// in the UI ever exposed them. "Continue," "Load Career," AND "New Career"
// all hardcoded slot 0. Three careers' worth of storage existed and was
// completely unreachable; every new career silently overwrote the last one
// with no warning. This is the missing screen that actually lets a player
// see, choose, and manage all 3 slots.

interface SaveSlotsScreenProps {
  onBack: () => void
  onPlaySlot: (slot: SaveSlotId) => void
  onNewCareerInSlot: (slot: SaveSlotId) => void
}

function phaseLabel(save: SaveGame): string {
  const phase = save.player.careerClock.phase
  if (phase === 'academy') return 'Academy'
  const season = save.player.careerClock.grassrootsSeason
  return `Grassroots${season ? ` · Season ${season}` : ''}`
}

export default function SaveSlotsScreen({ onBack, onPlaySlot, onNewCareerInSlot }: SaveSlotsScreenProps) {
  const [saves, setSaves] = useState<(SaveGame | undefined)[] | null>(null)
  const [confirmDelete, setConfirmDelete] = useState<SaveSlotId | null>(null)
  const [confirmOverwrite, setConfirmOverwrite] = useState<SaveSlotId | null>(null)

  useEffect(() => {
    listSaves().then(setSaves)
  }, [])

  const handleDelete = async (slot: SaveSlotId) => {
    await deleteSave(slot)
    setSaves(await listSaves())
    setConfirmDelete(null)
  }

  return (
    <div className="min-h-screen w-full bg-ks-black flex flex-col">
      <div className="sticky top-0 z-20 bg-ks-black/95 backdrop-blur border-b border-ks-border/50">
        <div className="max-w-md mx-auto w-full px-4 py-3 flex items-center gap-3">
          <button onClick={onBack} className="text-ks-muted hover:text-ks-gold transition-colors text-lg leading-none" aria-label="Back">←</button>
          <span className="font-display tracking-widest text-[11px] text-ks-gold uppercase">Save Slots</span>
        </div>
      </div>

      <div className="flex-1 max-w-md mx-auto w-full px-4 py-6 flex flex-col gap-3">
        {saves === null && <div className="text-center text-ks-muted text-[11px] py-8">Loading saves…</div>}

        {saves?.map((save, i) => {
          const slot = i as SaveSlotId
          if (!save) {
            return (
              <button
                key={slot}
                onClick={() => onNewCareerInSlot(slot)}
                className="w-full rounded-xl border border-dashed border-ks-border px-4 py-6 flex flex-col items-center gap-1 hover:border-ks-gold/40 transition-colors"
              >
                <span className="text-ks-muted text-2xl leading-none">+</span>
                <span className="text-[11px] text-ks-muted uppercase tracking-widest">Empty slot — start a new career</span>
              </button>
            )
          }

          const ovr = toOvr(computeCurrentAbility(save.player))
          const savedDate = new Date(save.savedAt)

          return (
            <div key={slot} className="rounded-xl border border-ks-border bg-[#0f0f0d] px-4 py-3.5 flex flex-col gap-2.5 texture-turf relative">
              <div className="flex items-center justify-between relative z-10">
                <div className="flex flex-col">
                  <span className="font-display text-lg text-ks-ink tracking-wide">{save.player.name}</span>
                  <span className="text-[10px] text-ks-muted uppercase tracking-widest">
                    {save.player.position} · {phaseLabel(save)} · age {save.player.careerClock.ageYears}
                  </span>
                </div>
                <div className="flex flex-col items-end">
                  <span className="font-display text-2xl text-ks-gold tabular-nums">{ovr}</span>
                  <span className="text-[9px] text-ks-muted uppercase tracking-widest">OVR</span>
                </div>
              </div>
              <span className="text-[10px] text-ks-muted/70 relative z-10">
                Last played {savedDate.toLocaleDateString()} at {savedDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
              <div className="flex gap-2 mt-1 relative z-10">
                <button
                  onClick={() => onPlaySlot(slot)}
                  className="flex-1 rounded-lg bg-ks-gold text-ks-black font-display tracking-widest text-[11px] uppercase py-2.5"
                >
                  Continue
                </button>
                {confirmDelete === slot ? (
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => handleDelete(slot)}
                      className="rounded-lg border border-red-500/60 text-red-400 text-[10px] uppercase tracking-widest px-3 py-2.5"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => setConfirmDelete(null)}
                      className="rounded-lg border border-ks-border text-ks-muted text-[10px] uppercase tracking-widest px-3 py-2.5"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmDelete(slot)}
                    className="rounded-lg border border-ks-border text-ks-muted text-[10px] uppercase tracking-widest px-3 py-2.5"
                  >
                    Delete
                  </button>
                )}
              </div>
              {confirmOverwrite === slot ? (
                <div className="flex items-center gap-2 relative z-10 text-[10px]">
                  <span className="text-ks-muted flex-1">Overwrite {save.player.name}'s career with a new one?</span>
                  <button onClick={() => onNewCareerInSlot(slot)} className="rounded-lg border border-ks-gold/60 text-ks-gold uppercase tracking-widest px-3 py-1.5">Confirm</button>
                  <button onClick={() => setConfirmOverwrite(null)} className="rounded-lg border border-ks-border text-ks-muted uppercase tracking-widest px-3 py-1.5">Cancel</button>
                </div>
              ) : (
                <button
                  onClick={() => setConfirmOverwrite(slot)}
                  className="text-[10px] text-ks-muted/60 uppercase tracking-widest underline decoration-dotted relative z-10 self-start"
                >
                  Start a new career here instead
                </button>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
