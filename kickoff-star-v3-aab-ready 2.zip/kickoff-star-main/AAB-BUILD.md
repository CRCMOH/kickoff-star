# Kickoff Star V3 — AAB Build

## One-command build

From the project root:

```bash
npm install
npm run build:aab
```

The bundle is generated at:

`android/app/build/outputs/bundle/release/app-release.aab`

The first `npm install` is a one-time dependency setup. After that, `npm run build:aab` performs:

1. TypeScript/Vite production build
2. Capacitor Android sync
3. Gradle release AAB build

## Google Play signing

A release AAB must be signed for Google Play. This project supports environment-variable signing so secrets do not need to be committed.

Set:

- `KEYSTORE_PATH`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

Then run:

```bash
npm run build:aab
```

For local testing without a release keystore:

```bash
npm run build:aab:unsigned
```

The Android application ID is `com.vraxis.kickoffstar`.

V3 Android version:

- versionName: `3.0.0`
- versionCode: `3`
